<?php
require_once 'includes/db_connect.php';
require_login();

echo "<h3>Debugging Messenger System</h3>";

// Check if messages table exists
try {
    $stmt = $pdo->query("DESCRIBE messages");
    echo "<p>✅ Messages table exists</p>";
    echo "<pre>";
    while ($row = $stmt->fetch()) {
        print_r($row);
    }
    echo "</pre>";
} catch (Exception $e) {
    echo "<p>❌ Messages table error: " . $e->getMessage() . "</p>";
}

// Test data insertion
echo "<h4>Test Message Insert:</h4>";
try {
    $current_user_id = $_SESSION['user_id'];
    
    // Get another user for testing
    $stmt = $pdo->prepare("SELECT id FROM users WHERE id != ? LIMIT 1");
    $stmt->execute([$current_user_id]);
    $test_user = $stmt->fetch();
    
    if ($test_user) {
        $stmt = $pdo->prepare("
            INSERT INTO messages (sender_id, receiver_id, message, timestamp, is_read) 
            VALUES (?, ?, ?, NOW(), 0)
        ");
        
        $result = $stmt->execute([$current_user_id, $test_user['id'], 'Test message from debug script']);
        
        if ($result) {
            echo "<p>✅ Test message inserted successfully</p>";
        } else {
            echo "<p>❌ Failed to insert test message</p>";
        }
    } else {
        echo "<p>⚠️ Need at least 2 users to test messaging</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Insert error: " . $e->getMessage() . "</p>";
}

// Check existing messages
echo "<h4>Existing Messages:</h4>";
try {
    $stmt = $pdo->query("SELECT * FROM messages ORDER BY timestamp DESC LIMIT 5");
    $messages = $stmt->fetchAll();
    
    if (empty($messages)) {
        echo "<p>No messages found</p>";
    } else {
        echo "<pre>";
        print_r($messages);
        echo "</pre>";
    }
} catch (Exception $e) {
    echo "<p>❌ Query error: " . $e->getMessage() . "</p>";
}

// Check users table
echo "<h4>Available Users:</h4>";
try {
    $stmt = $pdo->query("SELECT id, username, full_name FROM users LIMIT 5");
    $users = $stmt->fetchAll();
    echo "<pre>";
    print_r($users);
    echo "</pre>";
} catch (Exception $e) {
    echo "<p>❌ Users query error: " . $e->getMessage() . "</p>";
}
?>