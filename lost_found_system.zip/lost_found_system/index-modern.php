<?php
require_once 'includes/db_connect.php';

// Get recent items (last 12 items)
$stmt = $pdo->prepare("
    SELECT i.*, u.username, u.full_name 
    FROM items i 
    JOIN users u ON i.user_id = u.id 
    ORDER BY i.created_at DESC 
    LIMIT 12
");
$stmt->execute();
$recent_items = $stmt->fetchAll();

// Get statistics
$stmt = $pdo->query("SELECT COUNT(*) as total_items FROM items");
$total_items = $stmt->fetch()['total_items'];

$stmt = $pdo->query("SELECT COUNT(*) as lost_items FROM items WHERE status = 'Lost' AND is_resolved = 0");
$lost_items = $stmt->fetch()['lost_items'];

$stmt = $pdo->query("SELECT COUNT(*) as found_items FROM items WHERE status = 'Found' AND is_resolved = 0");
$found_items = $stmt->fetch()['found_items'];

$stmt = $pdo->query("SELECT COUNT(*) as resolved_items FROM items WHERE is_resolved = 1");
$resolved_items = $stmt->fetch()['resolved_items'];

$page_title = 'Dashboard - Lost & Found Hub';
include 'includes/modern-header.php';
?>

<!-- Enhanced Hero Section -->
<div class="search-section rounded-4 mb-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 mx-auto text-center">
                <h1 class="display-4 fw-bold mb-4">
                    <i class="fas fa-search-location me-3"></i>
                    Lost Something? Found Something?
                </h1>
                <p class="lead mb-5 fs-4">
                    Join our community-driven platform to reunite people with their lost belongings. 
                    Every item has a story, every search has hope.
                </p>
                
                <!-- Enhanced Quick Search -->
                <form action="search.php" method="GET" class="row g-3 justify-content-center">
                    <div class="col-md-5">
                        <div class="position-relative">
                            <input type="text" class="form-control form-control-lg ps-5" name="q" 
                                   placeholder="What are you looking for?" 
                                   value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q']) : ''; ?>">
                            <i class="fas fa-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select form-select-lg" name="category">
                            <option value="">All Categories</option>
                            <option value="Phone">📱 Phone</option>
                            <option value="Wallet">💳 Wallet</option>
                            <option value="ID">🆔 ID Card</option>
                            <option value="Keys">🔑 Keys</option>
                            <option value="Jewelry">💎 Jewelry</option>
                            <option value="Electronics">💻 Electronics</option>
                            <option value="Clothing">👕 Clothing</option>
                            <option value="Books">📚 Books</option>
                            <option value="Other">📦 Other</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-light btn-lg w-100 fw-bold">
                            <i class="fas fa-search me-2"></i>Search
                        </button>
                    </div>
                </form>
                
                <!-- Quick Action Buttons -->
                <div class="row mt-4 g-3">
                    <div class="col-md-6">
                        <a href="report_lost.php" class="btn btn-outline-light btn-lg w-100 glass-effect">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Report Lost Item
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="report_found.php" class="btn btn-outline-light btn-lg w-100 glass-effect">
                            <i class="fas fa-check-circle me-2"></i>
                            Report Found Item
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced Statistics -->
<div class="row mb-5 g-4">
    <div class="col-lg-3 col-md-6">
        <div class="stats-card">
            <div class="stats-icon">
                <i class="fas fa-list-alt"></i>
            </div>
            <h4 class="gradient-text"><?php echo number_format($total_items); ?></h4>
            <p class="fs-5 fw-medium">Total Reports</p>
            <small class="text-muted">Items reported in our system</small>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="stats-card">
            <div class="stats-icon text-danger">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h4 class="text-danger"><?php echo number_format($lost_items); ?></h4>
            <p class="fs-5 fw-medium">Lost Items</p>
            <small class="text-muted">Currently missing items</small>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="stats-card">
            <div class="stats-icon text-success">
                <i class="fas fa-check-circle"></i>
            </div>
            <h4 class="text-success"><?php echo number_format($found_items); ?></h4>
            <p class="fs-5 fw-medium">Found Items</p>
            <small class="text-muted">Waiting to be claimed</small>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="stats-card">
            <div class="stats-icon text-primary">
                <i class="fas fa-handshake"></i>
            </div>
            <h4 class="text-primary"><?php echo number_format($resolved_items); ?></h4>
            <p class="fs-5 fw-medium">Reunited</p>
            <small class="text-muted">Successfully returned items</small>
        </div>
    </div>
</div>

<!-- Recent Reports Section -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="gradient-text mb-0">
        <i class="fas fa-clock me-3"></i>Recent Activity
    </h2>
    <div class="btn-group shadow-soft" role="group">
        <a href="lost_items.php" class="btn btn-outline-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>View All Lost
        </a>
        <a href="found_items.php" class="btn btn-outline-success">
            <i class="fas fa-check-circle me-2"></i>View All Found
        </a>
    </div>
</div>

<?php if (empty($recent_items)): ?>
    <div class="text-center py-5">
        <div class="mb-4">
            <i class="fas fa-inbox fa-4x text-muted opacity-50"></i>
        </div>
        <h3 class="gradient-text mb-3">No Items Reported Yet</h3>
        <p class="text-muted fs-5 mb-4">Be the first to help someone in our community!</p>
        <div class="row g-3 justify-content-center">
            <div class="col-md-4">
                <a href="report_lost.php" class="btn btn-danger btn-lg w-100 shadow-soft">
                    <i class="fas fa-exclamation-triangle me-2"></i>Report Lost Item
                </a>
            </div>
            <div class="col-md-4">
                <a href="report_found.php" class="btn btn-success btn-lg w-100 shadow-soft">
                    <i class="fas fa-check-circle me-2"></i>Report Found Item
                </a>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="item-grid">
        <?php foreach ($recent_items as $item): ?>
            <div class="card">
                <?php if ($item['image_path']): ?>
                    <img src="<?php echo htmlspecialchars($item['image_path']); ?>" 
                         class="card-img-top lightbox-trigger" 
                         alt="<?php echo htmlspecialchars($item['title']); ?>"
                         style="cursor: pointer;"
                         data-lightbox="recent-items"
                         data-title="<?php echo htmlspecialchars($item['title']); ?>">
                <?php else: ?>
                    <div class="card-img-top bg-gradient d-flex align-items-center justify-content-center" 
                         style="height: 220px; background: linear-gradient(135deg, #f8f9fa, #e9ecef);">
                        <i class="fas fa-image fa-4x text-muted opacity-50"></i>
                    </div>
                <?php endif; ?>
                
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <h5 class="card-title mb-0 fw-bold">
                            <?php echo htmlspecialchars($item['title']); ?>
                        </h5>
                        <span class="status-badge status-<?php echo strtolower($item['status']); ?> <?php echo $item['is_resolved'] ? 'status-resolved' : ''; ?>">
                            <?php echo $item['is_resolved'] ? 'Reunited' : htmlspecialchars($item['status']); ?>
                        </span>
                    </div>
                    
                    <div class="category-icon category-<?php echo strtolower($item['category']); ?> mb-3">
                        <i class="fas fa-<?php echo getCategoryIcon($item['category']); ?>"></i>
                    </div>
                    
                    <p class="card-text text-muted mb-3 fs-6">
                        <?php echo htmlspecialchars(substr($item['description'], 0, 120)) . (strlen($item['description']) > 120 ? '...' : ''); ?>
                    </p>
                    
                    <div class="small text-muted mb-4">
                        <div class="mb-1">
                            <i class="fas fa-map-marker-alt me-2 text-primary"></i>
                            <span class="fw-medium"><?php echo htmlspecialchars($item['location']); ?></span>
                        </div>
                        <div class="mb-1">
                            <i class="fas fa-calendar me-2 text-success"></i>
                            <span><?php echo date('M j, Y', strtotime($item['date_reported'])); ?></span>
                        </div>
                        <div>
                            <i class="fas fa-user me-2 text-info"></i>
                            <span>by <strong><?php echo htmlspecialchars($item['username']); ?></strong></span>
                        </div>
                    </div>
                    
                    <a href="item_details.php?id=<?php echo $item['id']; ?>" 
                       class="btn btn-primary w-100 fw-medium shadow-soft">
                        <i class="fas fa-eye me-2"></i>View Details
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <div class="text-center mt-5">
        <a href="search.php" class="btn btn-outline-primary btn-lg px-5 shadow-soft">
            <i class="fas fa-search me-2"></i>Explore All Items
        </a>
    </div>
<?php endif; ?>

<!-- Call to Action Section -->
<div class="row mt-5 mb-4">
    <div class="col-12">
        <div class="card glass-effect border-0 shadow-strong">
            <div class="card-body text-center py-5">
                <h3 class="gradient-text mb-3">
                    <i class="fas fa-heart me-2"></i>
                    Help Build Our Community
                </h3>
                <p class="fs-5 text-muted mb-4">
                    Every report helps someone. Every search brings hope. Join thousands of people helping each other.
                </p>
                <div class="row g-3 justify-content-center">
                    <div class="col-md-3">
                        <a href="register.php" class="btn btn-primary btn-lg w-100">
                            <i class="fas fa-user-plus me-2"></i>Join Us
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="user_directory.php" class="btn btn-outline-primary btn-lg w-100">
                            <i class="fas fa-users me-2"></i>Community
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Lightbox CSS & JS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>

<?php
// Function to get category icon
function getCategoryIcon($category) {
    $icons = [
        'Phone' => 'mobile-alt',
        'Wallet' => 'wallet',
        'ID' => 'id-card',
        'Keys' => 'key',
        'Jewelry' => 'gem',
        'Electronics' => 'laptop',
        'Clothing' => 'tshirt',
        'Books' => 'book',
        'Other' => 'question'
    ];
    return $icons[$category] ?? 'question';
}

include 'includes/modern-footer.php';
?>