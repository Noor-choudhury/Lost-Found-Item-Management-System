<?php
require_once 'includes/db_connect.php';

// Require login to add comments
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_id = (int)$_POST['item_id'];
    $message = sanitize_input($_POST['message']);
    
    if (empty($message)) {
        header("Location: item_details.php?id=$item_id&error=empty_message");
        exit();
    }
    
    // Verify item exists
    $stmt = $pdo->prepare("SELECT id FROM items WHERE id = ?");
    $stmt->execute([$item_id]);
    
    if (!$stmt->fetch()) {
        header('Location: index.php');
        exit();
    }
    
    // Insert comment
    $stmt = $pdo->prepare("
        INSERT INTO comments (item_id, user_id, username, message) 
        VALUES (?, ?, ?, ?)
    ");
    
    if ($stmt->execute([$item_id, $_SESSION['user_id'], $_SESSION['username'], $message])) {
        header("Location: item_details.php?id=$item_id&success=comment_added");
    } else {
        header("Location: item_details.php?id=$item_id&error=comment_failed");
    }
} else {
    header('Location: index.php');
}

exit();
?>