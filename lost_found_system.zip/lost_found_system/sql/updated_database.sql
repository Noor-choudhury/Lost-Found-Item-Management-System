-- Updated Lost & Found Item Management System Database
-- MySQL Database Creation Script with Admin Support

CREATE DATABASE IF NOT EXISTS lost_found_db;
USE lost_found_db;

-- Users table for authentication with admin support
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    profile_image VARCHAR(255),
    role ENUM('user', 'admin') DEFAULT 'user',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Items table for lost and found reports
CREATE TABLE items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    category ENUM('Phone', 'Wallet', 'ID', 'Keys', 'Jewelry', 'Electronics', 'Clothing', 'Books', 'Other') NOT NULL,
    status ENUM('Lost', 'Found') NOT NULL,
    date_reported DATE NOT NULL,
    location VARCHAR(200) NOT NULL,
    contact_info VARCHAR(200),
    image_path VARCHAR(255),
    is_resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP NULL,
    admin_approved BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Comments table for item discussions
CREATE TABLE comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    user_id INT NOT NULL,
    username VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    admin_approved BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Site settings table for admin configuration
CREATE TABLE site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default admin user and sample data
INSERT INTO users (username, email, password, full_name, phone, role) VALUES 
('admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', '123-456-7890', 'admin'),
('john_doe', 'john@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John Doe', '098-765-4321', 'user');

INSERT INTO items (user_id, title, description, category, status, date_reported, location, contact_info) VALUES 
(2, 'Black iPhone 12', 'Lost my black iPhone 12 with a blue case', 'Phone', 'Lost', '2024-08-13', 'Central Park, near the fountain', 'Call 098-765-4321'),
(2, 'Found wallet', 'Brown leather wallet found with ID inside', 'Wallet', 'Found', '2024-08-12', 'Main Street Coffee Shop', 'Contact john@example.com'),
(2, 'Car keys with Toyota keychain', 'Lost my car keys with a Toyota keychain and house keys', 'Keys', 'Lost', '2024-08-11', 'Shopping Mall parking lot', 'Call 098-765-4321');

-- Insert default site settings
INSERT INTO site_settings (setting_key, setting_value) VALUES 
('site_name', 'Lost & Found System'),
('admin_email', 'admin@example.com'),
('items_per_page', '10'),
('require_approval', '0');