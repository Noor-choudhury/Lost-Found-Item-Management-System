-- Enhanced Lost & Found System Database
-- Includes messaging system and enhanced user features

USE lost_found_db;

-- Create messages table for private messaging
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    from_user_id INT NOT NULL,
    to_user_id INT NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    attachment_path VARCHAR(255) NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Add indexes for better performance
CREATE INDEX idx_messages_to_user ON messages(to_user_id);
CREATE INDEX idx_messages_from_user ON messages(from_user_id);
CREATE INDEX idx_messages_read ON messages(is_read);

-- Add profile image and bio fields to users if not exists
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS bio TEXT,
ADD COLUMN IF NOT EXISTS last_login TIMESTAMP NULL;

-- Update comments table to include profile images for better user experience
ALTER TABLE comments 
ADD COLUMN IF NOT EXISTS user_profile_image VARCHAR(255) NULL AFTER username;

-- Create notifications table for message notifications
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('message', 'comment', 'item_match') NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Add some sample messages for testing
INSERT INTO messages (from_user_id, to_user_id, subject, message) VALUES 
(1, 2, 'About your lost iPhone', 'Hi John, I think I might have found your iPhone. Please contact me to verify the details.'),
(2, 1, 'Re: About your lost iPhone', 'Thank you for reaching out! Could you please describe the phone case color?');

-- Add sample notifications
INSERT INTO notifications (user_id, type, title, message) VALUES 
(2, 'message', 'New Message', 'You have received a new message from admin'),
(1, 'message', 'New Message', 'You have received a new message from john_doe');