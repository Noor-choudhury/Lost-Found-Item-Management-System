-- SQL script to create messages table for the messenger system
-- Run this in your MySQL database

CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    message TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_read BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sender_receiver (sender_id, receiver_id),
    INDEX idx_timestamp (timestamp),
    INDEX idx_is_read (is_read)
);

-- Create conversations view for easier querying
CREATE VIEW conversation_list AS
SELECT 
    CASE 
        WHEN sender_id < receiver_id THEN CONCAT(sender_id, '_', receiver_id)
        ELSE CONCAT(receiver_id, '_', sender_id)
    END as conversation_id,
    CASE 
        WHEN sender_id < receiver_id THEN sender_id
        ELSE receiver_id
    END as user1_id,
    CASE 
        WHEN sender_id < receiver_id THEN receiver_id
        ELSE sender_id
    END as user2_id,
    MAX(timestamp) as last_message_time,
    COUNT(CASE WHEN is_read = FALSE THEN 1 END) as unread_count
FROM messages
GROUP BY conversation_id, user1_id, user2_id;