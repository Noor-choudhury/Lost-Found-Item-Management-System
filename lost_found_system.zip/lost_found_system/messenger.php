<?php
require_once 'includes/db_connect.php';
require_login();

$page_title = 'Messenger - Lost & Found System';
include 'includes/header.php';

// Get current user info
$current_user_id = $_SESSION['user_id'];

// Get user to chat with (if specified)
$chat_with_user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : null;
$chat_with_user = null;

if ($chat_with_user_id) {
    $stmt = $pdo->prepare("SELECT id, username, full_name, profile_image FROM users WHERE id = ?");
    $stmt->execute([$chat_with_user_id]);
    $chat_with_user = $stmt->fetch();
}
?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<style>
.messenger-container {
    height: calc(100vh - 120px);
    min-height: 600px;
}

.chat-sidebar {
    background: #0f0f0fff;
    border-right: 1px solid #010101ff;
    height: 100%;
    overflow-y: auto;
}

.chat-main {
    background: #060606ff;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.chat-header {
    background: #0f0f0fff;
    border-bottom: 1px solid #0b0b0bff;
    padding: 15px 20px;
    display: flex;
    align-items: center;
}

.chat-messages {
    flex: 1;
    overflow-y: auto;
    padding: 20px;
    background: linear-gradient(135deg, #000000ff 0%, #93331dff 100%);
}

.chat-input {
    background: #050505ff;
    border-top: 1px solid #070606ff;
    padding: 15px 20px;
}

.user-item {
    padding: 12px 15px;
    border-bottom: 1px solid #020202ff;
    cursor: pointer;
    transition: background-color 0.2s;
}

.user-item:hover {
    background: #030304ff;
}

.user-item.active {
    background: #131313ff;
    border-left: 3px solid #1976d2;
}

.user-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
}

.message-bubble {
    max-width: 70%;
    margin-bottom: 10px;
    position: relative;
}

.message-bubble.sent {
    margin-left: auto;
    text-align: right;
}

.message-bubble.received {
    margin-right: auto;
}

.message-content {
    padding: 12px 16px;
    border-radius: 20px;
    word-wrap: break-word;
}

.message-bubble.sent .message-content {
    background: #1976d2;
    color: white;
}

.message-bubble.received .message-content {
    background: #101010ff;
    color: #333;
    border: 1px solid #060606ff;
}

.message-time {
    font-size: 11px;
    margin-top: 5px;
    opacity: 0.7;
}

.unread-badge {
    background: #35dcc9ff;
    color: white;
    border-radius: 50%;
    font-size: 11px;
    padding: 2px 6px;
    min-width: 18px;
    text-align: center;
}

.typing-indicator {
    display: none;
    padding: 10px;
    font-style: italic;
    color: #000000ff;
}

.no-chat-selected {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: #666;
    font-size: 18px;
}

@media (max-width: 768px) {
    .chat-sidebar {
        display: none;
    }
    .chat-sidebar.mobile-show {
        display: block;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 1000;
    }
    .message-bubble {
        max-width: 85%;
    }
}
</style>

<div class="container-fluid p-0">
    <div class="row g-0 messenger-container">
        <!-- Chat Sidebar -->
        <div class="col-md-4 col-lg-3 chat-sidebar" id="chatSidebar">
            <div class="d-flex justify-content-between align-items-center p-3 border-bottom">
                <h5 class="mb-0">Chats</h5>
                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#newChatModal">
                    <i class="fas fa-plus"></i>
                </button>
            </div>
            <div id="chatList">
                <!-- Chat list will be loaded here -->
            </div>
        </div>

        <!-- Chat Main Area -->
        <div class="col-md-8 col-lg-9 chat-main">
            <?php if ($chat_with_user): ?>
                <!-- Chat Header -->
                <div class="chat-header">
                    <button class="btn btn-sm btn-outline-secondary d-md-none me-3" onclick="toggleSidebar()">
                        <i class="fas fa-bars"></i>
                    </button>
                    <?php if ($chat_with_user['profile_image'] && file_exists($chat_with_user['profile_image'])): ?>
                        <img src="<?php echo htmlspecialchars($chat_with_user['profile_image']); ?>" 
                             alt="Profile" class="user-avatar me-3">
                    <?php else: ?>
                        <div class="user-avatar me-3 bg-primary d-flex align-items-center justify-content-center">
                            <i class="fas fa-user text-white"></i>
                        </div>
                    <?php endif; ?>
                    <div>
                        <h6 class="mb-0"><?php echo htmlspecialchars($chat_with_user['full_name']); ?></h6>
                        <small class="text-muted">@<?php echo htmlspecialchars($chat_with_user['username']); ?></small>
                    </div>
                    <div class="ms-auto">
                        <span class="online-status" id="onlineStatus"></span>
                    </div>
                </div>

                <!-- Messages Area -->
                <div class="chat-messages" id="messagesArea">
                    <!-- Messages will be loaded here -->
                </div>

                <!-- Typing Indicator -->
                <div class="typing-indicator" id="typingIndicator">
                    <i class="fas fa-ellipsis-h"></i> Typing...
                </div>

                <!-- Message Input -->
                <div class="chat-input">
                    <form id="messageForm" class="d-flex">
                        <input type="text" 
                               class="form-control me-2" 
                               id="messageInput" 
                               placeholder="Type a message..." 
                               autocomplete="off">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <div class="no-chat-selected">
                    <div class="text-center">
                        <i class="fas fa-comments fa-4x mb-3 text-muted"></i>
                        <h4>Select a chat to start messaging</h4>
                        <p class="text-muted">Choose from your existing conversations or start a new one</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- New Chat Modal -->
<div class="modal fade" id="newChatModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Start New Chat</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="text" class="form-control mb-3" id="userSearch" placeholder="Search users...">
                <div id="userSearchResults">
                    <!-- Search results will appear here -->
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
const currentUserId = <?php echo $current_user_id; ?>;
const chatWithUserId = <?php echo $chat_with_user_id ?? 'null'; ?>;
let lastMessageId = 0;
let chatRefreshInterval;

$(document).ready(function() {
    loadChatList();
    
    if (chatWithUserId) {
        loadMessages();
        startMessagePolling();
    }
    
    // Message form submission
    $('#messageForm').on('submit', function(e) {
        e.preventDefault();
        sendMessage();
    });
    
    // User search
    $('#userSearch').on('input', function() {
        searchUsers($(this).val());
    });
    
    // Auto-focus message input
    $('#messageInput').focus();
});

function loadChatList() {
    $.get('get_chat_list.php', function(data) {
        $('#chatList').html(data);
    });
}

function loadMessages() {
    if (!chatWithUserId) return;
    
    $.get('get_messages.php', {
        user_id: chatWithUserId,
        last_id: lastMessageId
    }, function(data) {
        if (data.messages && data.messages.length > 0) {
            if (lastMessageId === 0) {
                $('#messagesArea').html('');
            }
            
            data.messages.forEach(function(message) {
                appendMessage(message);
                lastMessageId = Math.max(lastMessageId, message.id);
            });
            
            scrollToBottom();
        }
    }, 'json');
}

function appendMessage(message) {
    const isSent = message.sender_id == currentUserId;
    const bubbleClass = isSent ? 'sent' : 'received';
    const timeFormatted = new Date(message.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    
    const messageHtml = `
        <div class="message-bubble ${bubbleClass}">
            <div class="message-content">
                ${escapeHtml(message.message)}
            </div>
            <div class="message-time">${timeFormatted}</div>
        </div>
    `;
    
    $('#messagesArea').append(messageHtml);
}

function sendMessage() {
    const message = $('#messageInput').val().trim();
    if (!message || !chatWithUserId) return;
    
    $.post('send_message.php', {
        receiver_id: chatWithUserId,
        message: message
    }, function(response) {
        if (response.success) {
            $('#messageInput').val('');
            loadMessages();
            loadChatList();
        } else {
            alert('Failed to send message');
        }
    }, 'json');
}

function startMessagePolling() {
    chatRefreshInterval = setInterval(function() {
        loadMessages();
        loadChatList();
    }, 3000);
}

function searchUsers(query) {
    if (query.length < 2) {
        $('#userSearchResults').html('');
        return;
    }
    
    $.get('search_users.php', {q: query}, function(data) {
        $('#userSearchResults').html(data);
    });
}

function startChat(userId, userName) {
    window.location.href = `messenger.php?user_id=${userId}`;
}

function scrollToBottom() {
    const messagesArea = $('#messagesArea')[0];
    messagesArea.scrollTop = messagesArea.scrollHeight;
}

function toggleSidebar() {
    $('#chatSidebar').toggleClass('mobile-show');
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

// Cleanup on page unload
$(window).on('beforeunload', function() {
    if (chatRefreshInterval) {
        clearInterval(chatRefreshInterval);
    }
});
</script>

<?php include 'includes/footer.php'; ?>