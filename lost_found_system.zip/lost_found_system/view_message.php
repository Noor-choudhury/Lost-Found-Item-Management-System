<?php
require_once 'includes/db_connect.php';
require_login();

$message_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$message_id) {
    header('Location: messages.php');
    exit();
}

// Get message details with user information
$stmt = $pdo->prepare("
    SELECT m.*, 
           sender.username as sender_username, sender.full_name as sender_name, sender.profile_image as sender_image,
           recipient.username as recipient_username, recipient.full_name as recipient_name, recipient.profile_image as recipient_image
    FROM messages m
    LEFT JOIN users sender ON m.from_user_id = sender.id
    LEFT JOIN users recipient ON m.to_user_id = recipient.id
    WHERE m.id = ? AND (m.from_user_id = ? OR m.to_user_id = ?)
");
$stmt->execute([$message_id, $_SESSION['user_id'], $_SESSION['user_id']]);
$message = $stmt->fetch();

if (!$message) {
    header('Location: messages.php');
    exit();
}

$is_received = $message['to_user_id'] == $_SESSION['user_id'];

// Mark as read if it's a received message
if ($is_received && !$message['is_read']) {
    $stmt = $pdo->prepare("UPDATE messages SET is_read = 1 WHERE id = ?");
    $stmt->execute([$message_id]);
    $message['is_read'] = 1;
}

$other_user = $is_received ? 
    ['name' => $message['sender_name'], 'username' => $message['sender_username'], 'image' => $message['sender_image'], 'id' => $message['from_user_id']] :
    ['name' => $message['recipient_name'], 'username' => $message['recipient_username'], 'image' => $message['recipient_image'], 'id' => $message['to_user_id']];

$page_title = htmlspecialchars($message['subject']) . ' - Messages';
include 'includes/header.php';
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <!-- Header -->
            <div class="d-flex align-items-center mb-4">
                <a href="messages.php" class="btn btn-outline-secondary me-3">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div class="flex-grow-1">
                    <h2 class="mb-0">Message Details</h2>
                    <p class="text-muted mb-0">
                        <?php echo $is_received ? 'From' : 'To'; ?>: <?php echo htmlspecialchars($other_user['name']); ?>
                    </p>
                </div>
                <div class="btn-group">
                    <?php if ($is_received): ?>
                        <a href="send_message.php?to_user_id=<?php echo $message['from_user_id']; ?>" 
                           class="btn btn-primary">
                            <i class="fas fa-reply me-1"></i>Reply
                        </a>
                    <?php endif; ?>
                    <a href="user_profile.php?user_id=<?php echo $other_user['id']; ?>" 
                       class="btn btn-outline-info">
                        <i class="fas fa-user me-1"></i>View Profile
                    </a>
                </div>
            </div>

            <!-- Message Card -->
            <div class="card shadow-sm">
                <!-- Message Header -->
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <!-- Profile Image -->
                        <div class="me-3">
                            <?php if ($other_user['image'] && file_exists($other_user['image'])): ?>
                                <img src="<?php echo htmlspecialchars($other_user['image']); ?>" 
                                     alt="Profile" 
                                     class="rounded-circle" 
                                     style="width: 50px; height: 50px; object-fit: cover;">
                            <?php else: ?>
                                <div class="bg-light rounded-circle d-flex align-items-center justify-content-center" 
                                     style="width: 50px; height: 50px;">
                                    <i class="fas fa-user fa-lg text-muted"></i>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Message Info -->
                        <div class="flex-grow-1">
                            <div class="d-flex align-items-center justify-content-between">
                                <div>
                                    <h5 class="mb-0">
                                        <a href="user_profile.php?user_id=<?php echo $other_user['id']; ?>" 
                                           class="text-decoration-none">
                                            <?php echo htmlspecialchars($other_user['name']); ?>
                                        </a>
                                    </h5>
                                    <small class="text-muted">@<?php echo htmlspecialchars($other_user['username']); ?></small>
                                </div>
                                
                                <div class="text-end">
                                    <div class="mb-1">
                                        <?php if ($is_received): ?>
                                            <span class="badge bg-success">
                                                <i class="fas fa-arrow-down me-1"></i>Received
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-primary">
                                                <i class="fas fa-arrow-up me-1"></i>Sent
                                            </span>
                                        <?php endif; ?>
                                        
                                        <?php if ($message['attachment_path']): ?>
                                            <span class="badge bg-secondary ms-1">
                                                <i class="fas fa-paperclip"></i> Attachment
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <small class="text-muted">
                                        <i class="fas fa-clock me-1"></i>
                                        <?php echo date('M j, Y \a\t g:i A', strtotime($message['created_at'])); ?>
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Message Content -->
                <div class="card-body">
                    <!-- Subject -->
                    <div class="mb-3">
                        <h4 class="mb-0"><?php echo htmlspecialchars($message['subject']); ?></h4>
                    </div>

                    <!-- Message Text -->
                    <div class="mb-4">
                        <div class="border-start border-primary border-3 ps-3">
                            <?php echo nl2br(htmlspecialchars($message['message'])); ?>
                        </div>
                    </div>

                    <!-- Attachment -->
                    <?php if ($message['attachment_path'] && file_exists($message['attachment_path'])): ?>
                        <div class="card bg-light">
                            <div class="card-body">
                                <h6 class="card-title">
                                    <i class="fas fa-paperclip me-2"></i>Attachment
                                </h6>
                                
                                <?php
                                $filename = basename($message['attachment_path']);
                                $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                                $image_extensions = ['jpg', 'jpeg', 'png', 'gif'];
                                ?>
                                
                                <?php if (in_array($extension, $image_extensions)): ?>
                                    <!-- Image Attachment -->
                                    <div class="mb-3">
                                        <img src="<?php echo htmlspecialchars($message['attachment_path']); ?>" 
                                             alt="Attachment" 
                                             class="img-fluid rounded lightbox-trigger" 
                                             style="max-height: 300px; cursor: pointer;"
                                             data-lightbox="message-attachment"
                                             data-title="Message Attachment">
                                    </div>
                                <?php endif; ?>
                                
                                <!-- Download Link -->
                                <div class="d-flex align-items-center justify-content-between">
                                    <div>
                                        <i class="fas fa-file me-2"></i>
                                        <strong><?php echo htmlspecialchars($filename); ?></strong>
                                        <small class="text-muted ms-2">
                                            (<?php echo strtoupper($extension); ?> file)
                                        </small>
                                    </div>
                                    <a href="<?php echo htmlspecialchars($message['attachment_path']); ?>" 
                                       class="btn btn-outline-primary btn-sm" 
                                       download 
                                       target="_blank">
                                        <i class="fas fa-download me-1"></i>Download
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Message Actions -->
                <div class="card-footer bg-light">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <a href="messages.php" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left me-1"></i>Back to Messages
                            </a>
                        </div>
                        
                        <div class="btn-group">
                            <?php if ($is_received): ?>
                                <a href="send_message.php?to_user_id=<?php echo $message['from_user_id']; ?>" 
                                   class="btn btn-success">
                                    <i class="fas fa-reply me-1"></i>Reply
                                </a>
                            <?php endif; ?>
                            
                            <a href="user_profile.php?user_id=<?php echo $other_user['id']; ?>" 
                               class="btn btn-outline-info">
                                <i class="fas fa-user me-1"></i>View Profile
                            </a>
                            
                            <a href="send_message.php?to_user_id=<?php echo $other_user['id']; ?>" 
                               class="btn btn-outline-primary">
                                <i class="fas fa-envelope me-1"></i>New Message
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Related Actions -->
            <div class="card mt-4 shadow-sm">
                <div class="card-body">
                    <h6 class="card-title">
                        <i class="fas fa-lightbulb me-2"></i>Quick Actions
                    </h6>
                    <div class="row g-2">
                        <div class="col-md-4">
                            <a href="messages.php?filter=all" class="btn btn-outline-secondary btn-sm w-100">
                                <i class="fas fa-inbox me-1"></i>All Messages
                            </a>
                        </div>
                        <div class="col-md-4">
                            <a href="messages.php?filter=unread" class="btn btn-outline-warning btn-sm w-100">
                                <i class="fas fa-envelope me-1"></i>Unread Messages
                            </a>
                        </div>
                        <div class="col-md-4">
                            <a href="send_message.php" class="btn btn-outline-primary btn-sm w-100">
                                <i class="fas fa-plus me-1"></i>New Message
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Lightbox CSS & JS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>

<?php include 'includes/footer.php'; ?>