<?php
require_once 'includes/db_connect.php';
require_login();

header('Content-Type: application/json');

// Handle both GET (for direct links) and POST (for AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Handle GET request - show message form
    $to_user_id = isset($_GET['to_user_id']) ? (int)$_GET['to_user_id'] : 0;
    
    if (!$to_user_id) {
        header('Location: index.php');
        exit;
    }
    
    // Get recipient info
    $stmt = $pdo->prepare("SELECT id, username, full_name FROM users WHERE id = ?");
    $stmt->execute([$to_user_id]);
    $recipient = $stmt->fetch();
    
    if (!$recipient) {
        header('Location: index.php');
        exit;
    }
    
    // Redirect to messenger with the user
    header("Location: messenger.php?user_id=" . $to_user_id);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$current_user_id = $_SESSION['user_id'];
$receiver_id = isset($_POST['receiver_id']) ? (int)$_POST['receiver_id'] : 0;
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

// Validate input
if (!$receiver_id || empty($message)) {
    echo json_encode(['success' => false, 'error' => 'Invalid input']);
    exit;
}

// Prevent sending message to self
if ($receiver_id == $current_user_id) {
    echo json_encode(['success' => false, 'error' => 'Cannot send message to yourself']);
    exit;
}

// Verify receiver exists
$stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
$stmt->execute([$receiver_id]);
if (!$stmt->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Receiver not found']);
    exit;
}

// Sanitize message
$message = sanitize_input($message);

// Insert message
try {
    $stmt = $pdo->prepare("
        INSERT INTO messages (sender_id, receiver_id, message, timestamp, is_read) 
        VALUES (?, ?, ?, NOW(), 0)
    ");
    
    $stmt->execute([$current_user_id, $receiver_id, $message]);
    
    echo json_encode([
        'success' => true,
        'message_id' => $pdo->lastInsertId(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>