<?php
require_once 'includes/db_connect.php';
require_login();

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Get current user information
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize_input($_POST['full_name']);
    $email = sanitize_input($_POST['email']);
    $phone = sanitize_input($_POST['phone']);
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validation
    if (empty($full_name) || empty($email)) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Check if email is already taken by another user
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $user_id]);
        
        if ($stmt->fetch()) {
            $error = 'Email address is already taken.';
        } else {
            // Handle profile image upload
            $profile_image = $user['profile_image']; // Keep existing image by default
            
            if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = 'assets/uploads/profiles/';
                
                // Create upload directory if it doesn't exist
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                $file_extension = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));
                $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
                
                // Check file size (2MB max for profile images)
                if ($_FILES['profile_image']['size'] > 2 * 1024 * 1024) {
                    $error = 'Profile image size too large. Maximum 2MB allowed.';
                } elseif (in_array($file_extension, $allowed_extensions)) {
                    $new_filename = 'profile_' . uniqid() . '.' . $file_extension;
                    $upload_path = $upload_dir . $new_filename;
                    
                    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
                        // Delete old profile image if it exists
                        if ($user['profile_image'] && file_exists($user['profile_image'])) {
                            unlink($user['profile_image']);
                        }
                        $profile_image = $upload_path;
                    } else {
                        $error = 'Failed to upload profile image.';
                    }
                } else {
                    $error = 'Invalid file type for profile image. Please upload JPG, PNG or GIF images only.';
                }
            }
            
            // Handle password change
            $update_password = false;
            $hashed_password = $user['password']; // Keep existing password by default
            
            if (!empty($new_password)) {
                if (empty($current_password)) {
                    $error = 'Please enter your current password to change it.';
                } elseif (!password_verify($current_password, $user['password'])) {
                    $error = 'Current password is incorrect.';
                } elseif (strlen($new_password) < 6) {
                    $error = 'New password must be at least 6 characters long.';
                } elseif ($new_password !== $confirm_password) {
                    $error = 'New passwords do not match.';
                } else {
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $update_password = true;
                }
            }
            
            if (!$error) {
                // Update user information
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, profile_image = ?, password = ? WHERE id = ?");
                
                if ($stmt->execute([$full_name, $email, $phone, $profile_image, $hashed_password, $user_id])) {
                    // Update session data
                    $_SESSION['full_name'] = $full_name;
                    
                    $success = 'Profile updated successfully!' . ($update_password ? ' Password has been changed.' : '');
                    
                    // Refresh user data
                    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $user = $stmt->fetch();
                } else {
                    $error = 'Failed to update profile. Please try again.';
                }
            }
        }
    }
}

$page_title = 'Edit Profile - Lost & Found System';
include 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-user-edit me-2"></i>Edit Profile</h5>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger" role="alert">
                        <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success" role="alert">
                        <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label for="full_name" class="form-label">Full Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="full_name" name="full_name" 
                                       value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" 
                                       value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" id="phone" name="phone" 
                                       value="<?php echo htmlspecialchars($user['phone']); ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Profile Image</label>
                                <div class="text-center">
                                    <div class="profile-image-container mb-3">
                                        <?php if ($user['profile_image'] && file_exists($user['profile_image'])): ?>
                                            <img src="<?php echo htmlspecialchars($user['profile_image']); ?>" 
                                                 alt="Current Profile" class="profile-image-current rounded-circle">
                                        <?php else: ?>
                                            <i class="fas fa-user-circle fa-5x text-muted"></i>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="profile-upload-area" onclick="document.getElementById('profile_image').click();">
                                        <input type="file" class="d-none" id="profile_image" name="profile_image" accept="image/*">
                                        <div class="profile-upload-text">
                                            <i class="fas fa-camera fa-2x text-muted mb-2"></i>
                                            <p class="mb-0 small">Change Photo</p>
                                        </div>
                                        <div class="profile-preview"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <h6 class="mb-3">Change Password (Optional)</h6>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">Current Password</label>
                                <input type="password" class="form-control" id="current_password" name="current_password">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="new_password" class="form-label">New Password</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" minlength="6">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Confirm New Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-between">
                        <a href="profile.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-1"></i>Back to Profile
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Profile
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
.profile-image-current {
    width: 100px;
    height: 100px;
    object-fit: cover;
}

.profile-upload-area {
    border: 2px dashed #ddd;
    border-radius: 10px;
    padding: 15px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.profile-upload-area:hover {
    border-color: #007bff;
    background-color: #f8f9fa;
}

.profile-preview img {
    width: 80px;
    height: 80px;
    object-fit: cover;
    border-radius: 50%;
    margin-top: 10px;
}
</style>

<script>
// Profile image preview
document.getElementById('profile_image').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const preview = document.querySelector('.profile-preview');
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.innerHTML = '<img src="' + e.target.result + '" alt="Preview">';
        }
        reader.readAsDataURL(file);
    }
});
</script>

<?php include 'includes/footer.php'; ?>