<?php
require_once 'includes/db_connect.php';

// Require login to update status
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_id = (int)$_POST['item_id'];
    
    // Verify user owns this item
    $stmt = $pdo->prepare("SELECT user_id FROM items WHERE id = ? AND user_id = ?");
    $stmt->execute([$item_id, $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        header('Location: index.php');
        exit();
    }
    
    // Update item status to resolved
    $stmt = $pdo->prepare("
        UPDATE items 
        SET is_resolved = 1, resolved_at = NOW() 
        WHERE id = ? AND user_id = ?
    ");
    
    if ($stmt->execute([$item_id, $_SESSION['user_id']])) {
        header("Location: item_details.php?id=$item_id&success=status_updated");
    } else {
        header("Location: item_details.php?id=$item_id&error=status_failed");
    }
} else {
    header('Location: index.php');
}

exit();
?>