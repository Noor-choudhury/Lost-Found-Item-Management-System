<?php
require_once 'includes/db_connect.php';

// Get user ID from URL parameter or use current user
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0);

if (!$user_id) {
    header('Location: login.php');
    exit();
}

// Get user information
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: index.php');
    exit();
}

$is_own_profile = isset($_SESSION['user_id']) && $_SESSION['user_id'] == $user_id;

// Get user's items
$stmt = $pdo->prepare("SELECT * FROM items WHERE user_id = ? ORDER BY created_at DESC LIMIT 12");
$stmt->execute([$user_id]);
$user_items = $stmt->fetchAll();

// Get user stats
$stmt = $pdo->prepare("SELECT 
    COUNT(*) as total_items,
    SUM(CASE WHEN status = 'Lost' THEN 1 ELSE 0 END) as lost_items,
    SUM(CASE WHEN status = 'Found' THEN 1 ELSE 0 END) as found_items,
    SUM(CASE WHEN is_resolved = 1 THEN 1 ELSE 0 END) as resolved_items
    FROM items WHERE user_id = ?");
$stmt->execute([$user_id]);
$stats = $stmt->fetch();

$page_title = htmlspecialchars($user['full_name']) . "'s Profile - Lost & Found System";
include 'includes/header.php';
?>

<div class="row g-4">
    <!-- Profile Sidebar -->
    <div class="col-lg-4">
        <!-- Profile Card -->
        <div class="card">
            <div class="card-body text-center p-4">
                <div class="profile-image-container mb-4">
                    <?php if ($user['profile_image'] && file_exists($user['profile_image'])): ?>
                        <img src="<?php echo htmlspecialchars($user['profile_image']); ?>" 
                             alt="Profile Picture" 
                             class="profile-image-large">
                    <?php else: ?>
                        <div class="bg-gradient rounded-circle d-inline-flex align-items-center justify-content-center profile-image-large">
                            <i class="fas fa-user fa-3x text-white"></i>
                        </div>
                    <?php endif; ?>
                </div>
                
                <h4 class="fw-bold mb-2"><?php echo htmlspecialchars($user['full_name']); ?></h4>
                <p class="text-muted mb-3">@<?php echo htmlspecialchars($user['username']); ?></p>
                
                <div class="user-info mb-4">
                    <?php if ($user['email'] && ($is_own_profile || is_admin())): ?>
                        <div class="d-flex align-items-center justify-content-center mb-2">
                            <i class="fas fa-envelope text-muted me-2"></i>
                            <small class="text-muted"><?php echo htmlspecialchars($user['email']); ?></small>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($user['phone']): ?>
                        <div class="d-flex align-items-center justify-content-center mb-2">
                            <i class="fas fa-phone text-muted me-2"></i>
                            <small class="text-muted"><?php echo htmlspecialchars($user['phone']); ?></small>
                        </div>
                    <?php endif; ?>
                    
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="fas fa-calendar text-muted me-2"></i>
                        <small class="text-muted">Joined <?php echo date('M Y', strtotime($user['created_at'])); ?></small>
                    </div>
                </div>
                
                <?php if ($is_own_profile): ?>
                    <a href="edit_profile.php" class="btn btn-primary">
                        <i class="fas fa-edit me-2"></i>Edit Profile
                    </a>
                <?php else: ?>
                    <div class="d-grid gap-2">
                        <a href="contact_user.php?id=<?php echo $user_id; ?>" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-envelope me-2"></i>Contact User
                        </a>
                        <a href="search.php?user=<?php echo urlencode($user['username']); ?>" class="btn btn-outline-info btn-sm">
                            <i class="fas fa-search me-2"></i>View All Items
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Stats Card -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-bar me-2"></i>Activity Statistics
                </h5>
            </div>
            <div class="card-body">
                <div class="row g-3 text-center">
                    <div class="col-6">
                        <div class="stat-item p-3 bg-light rounded">
                            <h3 class="text-primary fw-bold mb-1"><?php echo $stats['total_items']; ?></h3>
                            <small class="text-muted">Total Reports</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-item p-3 bg-light rounded">
                            <h3 class="text-success fw-bold mb-1"><?php echo $stats['resolved_items']; ?></h3>
                            <small class="text-muted">Resolved</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-item p-3 bg-light rounded">
                            <h3 class="text-danger fw-bold mb-1"><?php echo $stats['lost_items']; ?></h3>
                            <small class="text-muted">Lost Items</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-item p-3 bg-light rounded">
                            <h3 class="text-warning fw-bold mb-1"><?php echo $stats['found_items']; ?></h3>
                            <small class="text-muted">Found Items</small>
                        </div>
                    </div>
                </div>
                
                <!-- Success Rate -->
                <?php if ($stats['total_items'] > 0): ?>
                    <?php $success_rate = round(($stats['resolved_items'] / $stats['total_items']) * 100, 1); ?>
                    <div class="mt-3 p-3 bg-light rounded">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <small class="text-muted fw-bold">Success Rate</small>
                            <small class="text-muted"><?php echo $success_rate; ?>%</small>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div class="progress-bar <?php echo $success_rate >= 70 ? 'bg-success' : ($success_rate >= 40 ? 'bg-warning' : 'bg-danger'); ?>" 
                                 role="progressbar" 
                                 style="width: <?php echo $success_rate; ?>%"
                                 aria-valuenow="<?php echo $success_rate; ?>" 
                                 aria-valuemin="0" 
                                 aria-valuemax="100"></div>
                        </div>
                        <small class="text-muted">Items successfully resolved</small>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Community Impact Card -->
        <?php if ($stats['total_items'] > 0): ?>
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-heart me-2"></i>Community Impact
                    </h5>
                </div>
                <div class="card-body">
                    <div class="text-center">
                        <?php
                        $impact_level = 'New Member';
                        $impact_color = 'secondary';
                        $impact_icon = 'fa-seedling';
                        
                        if ($stats['resolved_items'] >= 10) {
                            $impact_level = 'Community Hero';
                            $impact_color = 'success';
                            $impact_icon = 'fa-trophy';
                        } elseif ($stats['resolved_items'] >= 5) {
                            $impact_level = 'Helpful Member';
                            $impact_color = 'warning';
                            $impact_icon = 'fa-star';
                        } elseif ($stats['resolved_items'] >= 2) {
                            $impact_level = 'Active Helper';
                            $impact_color = 'info';
                            $impact_icon = 'fa-hands-helping';
                        } elseif ($stats['total_items'] >= 3) {
                            $impact_level = 'Contributing Member';
                            $impact_color = 'primary';
                            $impact_icon = 'fa-user-check';
                        } elseif ($stats['total_items'] >= 1) {
                            $impact_level = 'Getting Started';
                            $impact_color = 'success';
                            $impact_icon = 'fa-leaf';
                        }
                        ?>
                        
                        <div class="mb-3">
                            <i class="fas <?php echo $impact_icon; ?> fa-3x text-<?php echo $impact_color; ?>"></i>
                        </div>
                        
                        <h6 class="fw-bold text-<?php echo $impact_color; ?> mb-2"><?php echo $impact_level; ?></h6>
                        
                        <div class="small text-muted">
                            <?php if ($stats['resolved_items'] > 0): ?>
                                Helped resolve <strong><?php echo $stats['resolved_items']; ?></strong> 
                                item<?php echo $stats['resolved_items'] != 1 ? 's' : ''; ?>
                            <?php else: ?>
                                Ready to help the community
                            <?php endif; ?>
                        </div>
                        
                        <?php if (!$is_own_profile && $stats['resolved_items'] >= 2): ?>
                            <div class="mt-2">
                                <span class="badge bg-<?php echo $impact_color; ?> rounded-pill">Trusted Helper</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Main Content -->
    <div class="col-lg-8">
        <!-- Recent Items -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-history me-2"></i>Recent Reports
                </h5>
                <?php if ($is_own_profile && !empty($user_items)): ?>
                    <div class="btn-group btn-group-sm">
                        <a href="report_lost.php" class="btn btn-outline-danger">
                            <i class="fas fa-plus me-1"></i>Report Lost
                        </a>
                        <a href="report_found.php" class="btn btn-outline-success">
                            <i class="fas fa-plus me-1"></i>Report Found
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if (empty($user_items)): ?>
                    <div class="text-center py-5">
                        <div class="mb-4">
                            <i class="fas fa-inbox fa-4x text-muted"></i>
                        </div>
                        <h5 class="text-muted mb-3">No reports yet</h5>
                        <p class="text-muted mb-4">
                            <?php echo $is_own_profile ? 'Start helping the community by reporting lost or found items.' : 'This user hasn\'t reported any items yet.'; ?>
                        </p>
                        <?php if ($is_own_profile): ?>
                            <div class="d-flex gap-2 justify-content-center">
                                <a href="report_lost.php" class="btn btn-danger">
                                    <i class="fas fa-exclamation-triangle me-2"></i>Report Lost Item
                                </a>
                                <a href="report_found.php" class="btn btn-success">
                                    <i class="fas fa-check-circle me-2"></i>Report Found Item
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="row g-3">
                        <?php foreach ($user_items as $item): ?>
                            <div class="col-md-6">
                                <div class="card h-100 fade-in">
                                    <?php if ($item['image_path']): ?>
                                        <img src="<?php echo htmlspecialchars($item['image_path']); ?>" 
                                             class="card-img-top" 
                                             alt="Item image"
                                             style="height: 150px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 150px;">
                                            <i class="fas fa-image fa-2x text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="card-body d-flex flex-column">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <h6 class="card-title mb-0 fw-bold"><?php echo htmlspecialchars($item['title']); ?></h6>
                                            <span class="status-badge status-<?php echo strtolower($item['status']); ?> <?php echo $item['is_resolved'] ? 'status-resolved' : ''; ?>">
                                                <?php echo $item['is_resolved'] ? 'Resolved' : htmlspecialchars($item['status']); ?>
                                            </span>
                                        </div>
                                        
                                        <p class="card-text text-muted small mb-2">
                                            <?php echo htmlspecialchars(substr($item['description'], 0, 80)) . (strlen($item['description']) > 80 ? '...' : ''); ?>
                                        </p>
                                        
                                        <div class="small text-muted mb-3">
                                            <div class="d-flex align-items-center mb-1">
                                                <i class="fas fa-map-marker-alt me-2"></i>
                                                <span><?php echo htmlspecialchars($item['location']); ?></span>
                                            </div>
                                            <div class="d-flex align-items-center">
                                                <i class="fas fa-calendar me-2"></i>
                                                <span><?php echo date('M j, Y', strtotime($item['date_reported'])); ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-auto">
                                            <a href="item_details.php?id=<?php echo $item['id']; ?>" class="btn btn-primary btn-sm w-100">
                                                <i class="fas fa-eye me-1"></i>View Details
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if (count($user_items) >= 12): ?>
                        <div class="text-center mt-4">
                            <a href="search.php?user=<?php echo urlencode($user['username']); ?>" class="btn btn-outline-primary">
                                <i class="fas fa-list me-2"></i>View All Reports
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.stat-item {
    transition: all 0.3s ease;
}

.stat-item:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-sm);
}

.profile-image-container {
    position: relative;
    display: inline-block;
}

.user-info {
    border-top: 1px solid var(--gray-200);
    border-bottom: 1px solid var(--gray-200);
    padding: 1rem 0;
}
</style>

<?php include 'includes/footer.php'; ?>