<?php
require_once 'includes/db_connect.php';
require_login();

header('Content-Type: application/json');

$current_user_id = $_SESSION['user_id'];
$other_user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
$last_id = isset($_GET['last_id']) ? (int)$_GET['last_id'] : 0;

if (!$other_user_id) {
    echo json_encode(['success' => false, 'error' => 'Invalid user ID']);
    exit;
}

// Get messages between current user and other user
$stmt = $pdo->prepare("
    SELECT id, sender_id, receiver_id, message, timestamp
    FROM messages 
    WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
    AND id > ?
    ORDER BY timestamp ASC
");

$stmt->execute([$current_user_id, $other_user_id, $other_user_id, $current_user_id, $last_id]);
$messages = $stmt->fetchAll();

// Mark messages as read
if (!empty($messages)) {
    $message_ids = array_column($messages, 'id');
    $placeholders = str_repeat('?,', count($message_ids) - 1) . '?';
    
    $update_stmt = $pdo->prepare("
        UPDATE messages 
        SET is_read = 1 
        WHERE id IN ($placeholders) 
        AND receiver_id = ? 
        AND is_read = 0
    ");
    
    $update_stmt->execute(array_merge($message_ids, [$current_user_id]));
}

echo json_encode([
    'success' => true,
    'messages' => $messages,
    'count' => count($messages)
]);
?>