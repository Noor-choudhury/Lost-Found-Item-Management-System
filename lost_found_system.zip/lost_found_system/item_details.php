<?php
require_once 'includes/db_connect.php';

$item_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$item_id) {
    header('Location: index.php');
    exit();
}

// Get item details
$stmt = $pdo->prepare("
    SELECT i.*, u.username, u.full_name, u.email 
    FROM items i 
    JOIN users u ON i.user_id = u.id 
    WHERE i.id = ?
");
$stmt->execute([$item_id]);
$item = $stmt->fetch();

if (!$item) {
    header('Location: index.php');
    exit();
}

// Get comments
$stmt = $pdo->prepare("
    SELECT c.*, u.full_name 
    FROM comments c 
    JOIN users u ON c.user_id = u.id 
    WHERE c.item_id = ? 
    ORDER BY c.created_at DESC
");
$stmt->execute([$item_id]);
$comments = $stmt->fetchAll();

$page_title = htmlspecialchars($item['title']) . ' - Lost & Found System';
include 'includes/header.php';
?>

<div class="row">
    <!-- Item Details -->
    <div class="col-md-8">
        <div class="card mb-4">
            <?php if ($item['image_path']): ?>
                <img src="<?php echo htmlspecialchars($item['image_path']); ?>" 
                     class="card-img-top item-details-image lightbox-trigger" 
                     alt="Item image"
                     style="cursor: pointer;"
                     data-lightbox="item-details"
                     data-title="<?php echo htmlspecialchars($item['title']); ?>">
            <?php endif; ?>
            
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <h1 class="card-title mb-0"><?php echo htmlspecialchars($item['title']); ?></h1>
                    <span class="status-badge status-<?php echo strtolower($item['status']); ?> <?php echo $item['is_resolved'] ? 'status-resolved' : ''; ?>">
                        <?php echo $item['is_resolved'] ? 'Resolved' : htmlspecialchars($item['status']); ?>
                    </span>
                </div>
                
                <div class="category-icon category-<?php echo strtolower($item['category']); ?> mb-3">
                    <i class="fas fa-<?php echo getCategoryIcon($item['category']); ?>"></i>
                    <span class="ms-2"><?php echo htmlspecialchars($item['category']); ?></span>
                </div>
                
                <div class="row mb-3">
                    <div class="col-sm-6">
                        <strong><i class="fas fa-calendar me-2"></i>Date <?php echo $item['status'] === 'Lost' ? 'Lost' : 'Found'; ?>:</strong><br>
                        <?php echo date('F j, Y', strtotime($item['date_reported'])); ?>
                    </div>
                    <div class="col-sm-6">
                        <strong><i class="fas fa-map-marker-alt me-2"></i>Location:</strong><br>
                        <?php echo htmlspecialchars($item['location']); ?>
                    </div>
                </div>
                
                <div class="mb-3">
                    <strong><i class="fas fa-align-left me-2"></i>Description:</strong>
                    <p class="mt-2"><?php echo nl2br(htmlspecialchars($item['description'])); ?></p>
                </div>
                
                <?php if ($item['contact_info']): ?>
                    <div class="mb-3">
                        <strong><i class="fas fa-phone me-2"></i>Contact Information:</strong>
                        <div class="d-flex align-items-center mt-2">
                            <span class="me-2"><?php echo htmlspecialchars($item['contact_info']); ?></span>
                            <button class="btn btn-sm btn-outline-primary" onclick="copyToClipboard('<?php echo htmlspecialchars($item['contact_info']); ?>')">
                                <i class="fas fa-copy"></i>
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
                
                <div class="text-muted small">
                    <i class="fas fa-user me-1"></i>Reported by <?php echo htmlspecialchars($item['username']); ?> 
                    on <?php echo date('M j, Y \a\t g:i A', strtotime($item['created_at'])); ?>
                </div>
            </div>
        </div>
        
        <!-- Comments Section -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-comments me-2"></i>Comments & Discussion</h5>
            </div>
            <div class="card-body">
                <?php if (is_logged_in()): ?>
                    <!-- Add Comment Form -->
                    <form action="add_comment.php" method="POST" class="mb-4">
                        <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                        <div class="mb-3">
                            <label for="message" class="form-label">Add a Comment</label>
                            <textarea class="form-control" id="message" name="message" rows="3" 
                                      placeholder="Share any information that might help..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-comment me-1"></i>Post Comment
                        </button>
                    </form>
                    <hr>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <a href="login.php?redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>">Login</a> 
                        to post comments and communicate about this item.
                    </div>
                <?php endif; ?>
                
                <!-- Comments List -->
                <?php if (empty($comments)): ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-comment-slash fa-2x mb-2"></i>
                        <p>No comments yet. Be the first to share information about this item!</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($comments as $comment): ?>
                        <div class="comment-item">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div class="comment-author d-flex align-items-center">
                                    <?php
                                    // Get commenter's profile image
                                    $stmt_user = $pdo->prepare("SELECT profile_image FROM users WHERE username = ?");
                                    $stmt_user->execute([$comment['username']]);
                                    $commenter = $stmt_user->fetch();
                                    ?>
                                    
                                    <?php if ($commenter['profile_image'] && file_exists($commenter['profile_image'])): ?>
                                        <img src="<?php echo htmlspecialchars($commenter['profile_image']); ?>" 
                                             alt="Profile" 
                                             class="rounded-circle me-2" 
                                             style="width: 32px; height: 32px; object-fit: cover;">
                                    <?php else: ?>
                                        <i class="fas fa-user-circle fa-lg me-2 text-primary"></i>
                                    <?php endif; ?>
                                    
                                    <a href="user_profile.php?user_id=<?php echo $comment['user_id']; ?>" 
                                       class="text-decoration-none text-primary fw-bold">
                                        <?php echo htmlspecialchars($comment['username']); ?>
                                    </a>
                                </div>
                                <div class="comment-date">
                                    <?php echo date('M j, Y \a\t g:i A', strtotime($comment['created_at'])); ?>
                                </div>
                            </div>
                            <p class="mb-0"><?php echo nl2br(htmlspecialchars($comment['message'])); ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Sidebar -->
    <div class="col-md-4">
        <!-- Item Owner Profile -->
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="mb-0"><i class="fas fa-user me-2"></i>Item Owner</h6>
            </div>
            <div class="card-body text-center">
                <?php
                $stmt_owner = $pdo->prepare("SELECT profile_image FROM users WHERE id = ?");
                $stmt_owner->execute([$item['user_id']]);
                $owner = $stmt_owner->fetch();
                ?>
                
                <div class="mb-3">
                    <?php if ($owner['profile_image'] && file_exists($owner['profile_image'])): ?>
                        <img src="<?php echo htmlspecialchars($owner['profile_image']); ?>" 
                             alt="Profile" 
                             class="rounded-circle border border-2 border-primary" 
                             style="width: 60px; height: 60px; object-fit: cover;">
                    <?php else: ?>
                        <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center border border-2 border-light" 
                             style="width: 60px; height: 60px;">
                            <i class="fas fa-user fa-lg text-muted"></i>
                        </div>
                    <?php endif; ?>
                </div>
                
                <h6><?php echo htmlspecialchars($item['full_name']); ?></h6>
                <p class="text-muted small">@<?php echo htmlspecialchars($item['username']); ?></p>
                
                <div class="d-grid gap-2">
                    <a href="user_profile.php?user_id=<?php echo $item['user_id']; ?>" 
                       class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-user me-1"></i>View Profile
                    </a>
                    <?php if (is_logged_in() && $_SESSION['user_id'] != $item['user_id']): ?>
                        <a href="send_message.php?to_user_id=<?php echo $item['user_id']; ?>" 
                           class="btn btn-primary btn-sm">
                            <i class="fas fa-envelope me-1"></i>Send Message
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Status Update -->
        <?php if (is_logged_in() && $_SESSION['user_id'] == $item['user_id'] && !$item['is_resolved']): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-check-circle me-2"></i>Mark as Resolved</h6>
                </div>
                <div class="card-body">
                    <p class="card-text small">Found your item? Mark this report as resolved.</p>
                    <form action="update_status.php" method="POST">
                        <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                        <button type="submit" class="btn btn-success btn-sm w-100" 
                                onclick="return confirm('Are you sure you want to mark this item as resolved?')">
                            <i class="fas fa-check me-1"></i>Mark as Resolved
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Related Items -->
        <?php
        $related_stmt = $pdo->prepare("
            SELECT * FROM items 
            WHERE category = ? AND id != ? AND status != ? 
            ORDER BY created_at DESC 
            LIMIT 5
        ");
        $related_stmt->execute([$item['category'], $item['id'], $item['status']]);
        $related_items = $related_stmt->fetchAll();
        ?>
        
        <?php if (!empty($related_items)): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0">
                        <i class="fas fa-list me-2"></i>
                        Related <?php echo $item['status'] === 'Lost' ? 'Found' : 'Lost'; ?> Items
                    </h6>
                </div>
                <div class="card-body">
                    <?php foreach ($related_items as $related): ?>
                        <div class="d-flex mb-3">
                            <?php if ($related['image_path']): ?>
                                <img src="<?php echo htmlspecialchars($related['image_path']); ?>" 
                                     class="me-3 rounded" style="width: 60px; height: 60px; object-fit: cover;" 
                                     alt="Related item">
                            <?php else: ?>
                                <div class="me-3 bg-light rounded d-flex align-items-center justify-content-center" 
                                     style="width: 60px; height: 60px;">
                                    <i class="fas fa-image text-muted"></i>
                                </div>
                            <?php endif; ?>
                            <div class="flex-grow-1">
                                <h6 class="mb-1">
                                    <a href="item_details.php?id=<?php echo $related['id']; ?>" 
                                       class="text-decoration-none"><?php echo htmlspecialchars($related['title']); ?></a>
                                </h6>
                                <small class="text-muted">
                                    <i class="fas fa-map-marker-alt me-1"></i><?php echo htmlspecialchars($related['location']); ?>
                                </small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Actions -->
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0"><i class="fas fa-tools me-2"></i>Actions</h6>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo $item['status'] === 'Lost' ? 'lost_items.php' : 'found_items.php'; ?>" 
                       class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i>Back to <?php echo $item['status']; ?> Items
                    </a>
                    
                    <?php if (is_logged_in()): ?>
                        <a href="report_<?php echo strtolower($item['status'] === 'Lost' ? 'found' : 'lost'); ?>.php" 
                           class="btn btn-outline-<?php echo $item['status'] === 'Lost' ? 'success' : 'danger'; ?> btn-sm">
                            <i class="fas fa-plus me-1"></i>Report <?php echo $item['status'] === 'Lost' ? 'Found' : 'Lost'; ?> Item
                        </a>
                    <?php endif; ?>
                    
                    <a href="search.php?category=<?php echo urlencode($item['category']); ?>" 
                       class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-search me-1"></i>More <?php echo htmlspecialchars($item['category']); ?> Items
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Lightbox CSS & JS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>

<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        // Create temporary alert
        const alert = document.createElement('div');
        alert.className = 'alert alert-success position-fixed top-0 start-50 translate-middle-x mt-3';
        alert.style.zIndex = '9999';
        alert.innerHTML = '<i class="fas fa-check me-2"></i>Contact info copied to clipboard!';
        document.body.appendChild(alert);
        
        // Remove alert after 2 seconds
        setTimeout(() => {
            alert.remove();
        }, 2000);
    }).catch(function() {
        alert('Failed to copy to clipboard');
    });
}
</script>

<?php
function getCategoryIcon($category) {
    $icons = [
        'Phone' => 'mobile-alt',
        'Wallet' => 'wallet',
        'ID' => 'id-card',
        'Keys' => 'key',
        'Jewelry' => 'gem',
        'Electronics' => 'laptop',
        'Clothing' => 'tshirt',
        'Books' => 'book',
        'Other' => 'question'
    ];
    return $icons[$category] ?? 'question';
}

include 'includes/footer.php';
?>