<?php
require_once 'includes/db_connect.php';

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Sorting
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'date_desc';
$sort_options = [
    'date_desc' => 'i.created_at DESC',
    'date_asc' => 'i.created_at ASC',
    'title_asc' => 'i.title ASC',
    'title_desc' => 'i.title DESC',
    'location_asc' => 'i.location ASC'
];
$order_by = $sort_options[$sort] ?? $sort_options['date_desc'];

// Filtering
$category = isset($_GET['category']) ? $_GET['category'] : '';
$location = isset($_GET['location']) ? $_GET['location'] : '';

// Build WHERE clause
$where_conditions = ["i.status = 'Lost'"];
$params = [];

if ($category) {
    $where_conditions[] = "i.category = ?";
    $params[] = $category;
}

if ($location) {
    $where_conditions[] = "i.location LIKE ?";
    $params[] = "%$location%";
}

$where_clause = implode(' AND ', $where_conditions);

// Get total count for pagination
$count_sql = "SELECT COUNT(*) as total FROM items i WHERE $where_clause";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_items = $count_stmt->fetch()['total'];
$total_pages = ceil($total_items / $per_page);

// Get items
$sql = "
    SELECT i.*, u.username, u.full_name 
    FROM items i 
    JOIN users u ON i.user_id = u.id 
    WHERE $where_clause 
    ORDER BY $order_by 
    LIMIT $per_page OFFSET $offset
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

$page_title = 'Lost Items - Lost & Found System';
include 'includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1><i class="fas fa-exclamation-triangle text-danger me-2"></i>Lost Items</h1>
        <p class="text-muted mb-0">Help people find their lost belongings</p>
    </div>
    <a href="report_lost.php" class="btn btn-danger">
        <i class="fas fa-plus me-1"></i>Report Lost Item
    </a>
</div>

<!-- Search and Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-4">
                <label for="category" class="form-label">Category</label>
                <select class="form-select search-filter" name="category" id="category">
                    <option value="">All Categories</option>
                    <option value="Phone" <?php echo $category === 'Phone' ? 'selected' : ''; ?>>Phone</option>
                    <option value="Wallet" <?php echo $category === 'Wallet' ? 'selected' : ''; ?>>Wallet</option>
                    <option value="ID" <?php echo $category === 'ID' ? 'selected' : ''; ?>>ID</option>
                    <option value="Keys" <?php echo $category === 'Keys' ? 'selected' : ''; ?>>Keys</option>
                    <option value="Jewelry" <?php echo $category === 'Jewelry' ? 'selected' : ''; ?>>Jewelry</option>
                    <option value="Electronics" <?php echo $category === 'Electronics' ? 'selected' : ''; ?>>Electronics</option>
                    <option value="Clothing" <?php echo $category === 'Clothing' ? 'selected' : ''; ?>>Clothing</option>
                    <option value="Books" <?php echo $category === 'Books' ? 'selected' : ''; ?>>Books</option>
                    <option value="Other" <?php echo $category === 'Other' ? 'selected' : ''; ?>>Other</option>
                </select>
            </div>
            
            <div class="col-md-4">
                <label for="location" class="form-label">Location</label>
                <input type="text" class="form-control" name="location" id="location" 
                       placeholder="Enter location..." value="<?php echo htmlspecialchars($location); ?>">
            </div>
            
            <div class="col-md-4">
                <label for="sort" class="form-label">Sort by</label>
                <select class="form-select search-filter" name="sort" id="sort">
                    <option value="date_desc" <?php echo $sort === 'date_desc' ? 'selected' : ''; ?>>Newest First</option>
                    <option value="date_asc" <?php echo $sort === 'date_asc' ? 'selected' : ''; ?>>Oldest First</option>
                    <option value="title_asc" <?php echo $sort === 'title_asc' ? 'selected' : ''; ?>>Title A-Z</option>
                    <option value="title_desc" <?php echo $sort === 'title_desc' ? 'selected' : ''; ?>>Title Z-A</option>
                    <option value="location_asc" <?php echo $sort === 'location_asc' ? 'selected' : ''; ?>>Location A-Z</option>
                </select>
            </div>
            
            <div class="col-12">
                <button type="submit" class="btn btn-primary me-2">
                    <i class="fas fa-search me-1"></i>Apply Filters
                </button>
                <a href="lost_items.php" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-1"></i>Clear Filters
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Results Summary -->
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <span class="text-muted">
            Showing <?php echo min(($page - 1) * $per_page + 1, $total_items); ?> - 
            <?php echo min($page * $per_page, $total_items); ?> of <?php echo $total_items; ?> items
        </span>
    </div>
</div>

<!-- Items Grid -->
<?php if (empty($items)): ?>
    <div class="text-center py-5">
        <i class="fas fa-search fa-3x text-muted mb-3"></i>
        <h4>No lost items found</h4>
        <p class="text-muted">Try adjusting your search criteria or be the first to report a lost item.</p>
        <a href="report_lost.php" class="btn btn-danger">
            <i class="fas fa-plus me-1"></i>Report Lost Item
        </a>
    </div>
<?php else: ?>
    <div class="item-grid">
        <?php foreach ($items as $item): ?>
            <div class="card fade-in">
                <?php if ($item['image_path']): ?>
                    <img src="<?php echo htmlspecialchars($item['image_path']); ?>" class="card-img-top" alt="Item image">
                <?php else: ?>
                    <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
                        <i class="fas fa-image fa-3x text-muted"></i>
                    </div>
                <?php endif; ?>
                
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="card-title mb-0"><?php echo htmlspecialchars($item['title']); ?></h5>
                        <span class="status-badge status-lost <?php echo $item['is_resolved'] ? 'status-resolved' : ''; ?>">
                            <?php echo $item['is_resolved'] ? 'Resolved' : 'Lost'; ?>
                        </span>
                    </div>
                    
                    <div class="category-icon category-<?php echo strtolower($item['category']); ?> mb-2">
                        <i class="fas fa-<?php echo getCategoryIcon($item['category']); ?>"></i>
                    </div>
                    
                    <p class="card-text text-muted mb-2">
                        <?php echo htmlspecialchars(substr($item['description'], 0, 100)) . (strlen($item['description']) > 100 ? '...' : ''); ?>
                    </p>
                    
                    <div class="small text-muted mb-3">
                        <div><i class="fas fa-map-marker-alt me-1"></i><?php echo htmlspecialchars($item['location']); ?></div>
                        <div><i class="fas fa-calendar me-1"></i><?php echo date('M j, Y', strtotime($item['date_reported'])); ?></div>
                        <div><i class="fas fa-user me-1"></i>by <?php echo htmlspecialchars($item['username']); ?></div>
                    </div>
                    
                    <a href="item_details.php?id=<?php echo $item['id']; ?>" class="btn btn-danger btn-sm w-100">
                        <i class="fas fa-eye me-1"></i>View Details
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Lost items pagination" class="mt-4">
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page - 1; ?>&sort=<?php echo $sort; ?>&category=<?php echo $category; ?>&location=<?php echo urlencode($location); ?>">
                            <i class="fas fa-chevron-left"></i> Previous
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&sort=<?php echo $sort; ?>&category=<?php echo $category; ?>&location=<?php echo urlencode($location); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page + 1; ?>&sort=<?php echo $sort; ?>&category=<?php echo $category; ?>&location=<?php echo urlencode($location); ?>">
                            Next <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
<?php endif; ?>

<?php
function getCategoryIcon($category) {
    $icons = [
        'Phone' => 'mobile-alt',
        'Wallet' => 'wallet',
        'ID' => 'id-card',
        'Keys' => 'key',
        'Jewelry' => 'gem',
        'Electronics' => 'laptop',
        'Clothing' => 'tshirt',
        'Books' => 'book',
        'Other' => 'question'
    ];
    return $icons[$category] ?? 'question';
}

include 'includes/footer.php';
?>