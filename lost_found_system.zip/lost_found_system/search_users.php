<?php
require_once 'includes/db_connect.php';
require_login();

$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$current_user_id = $_SESSION['user_id'];

if (strlen($query) < 2) {
    echo '<div class="text-muted p-3">Enter at least 2 characters to search</div>';
    exit;
}

// Search users by username or full name
$stmt = $pdo->prepare("
    SELECT id, username, full_name, profile_image 
    FROM users 
    WHERE (username LIKE ? OR full_name LIKE ?) 
    AND id != ? 
    LIMIT 10
");

$search_term = '%' . $query . '%';
$stmt->execute([$search_term, $search_term, $current_user_id]);
$users = $stmt->fetchAll();

if (empty($users)): ?>
    <div class="text-muted p-3">No users found</div>
<?php else: ?>
    <?php foreach ($users as $user): ?>
        <div class="user-item" onclick="startChat(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')" 
             data-bs-dismiss="modal">
            <div class="d-flex align-items-center">
                <?php if ($user['profile_image'] && file_exists($user['profile_image'])): ?>
                    <img src="<?php echo htmlspecialchars($user['profile_image']); ?>" 
                         alt="Profile" class="user-avatar me-3">
                <?php else: ?>
                    <div class="user-avatar me-3 bg-secondary d-flex align-items-center justify-content-center">
                        <i class="fas fa-user text-white"></i>
                    </div>
                <?php endif; ?>
                
                <div>
                    <h6 class="mb-0"><?php echo htmlspecialchars($user['full_name']); ?></h6>
                    <small class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></small>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>