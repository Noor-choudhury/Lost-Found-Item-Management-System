<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'Lost & Found Hub'; ?></title>
    
    <!-- Preload Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/modern-style.css" rel="stylesheet">
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="assets/images/logo.svg">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <div class="brand-icon">
                    <i class="fas fa-search-location"></i>
                </div>
                <span style="color: white !important;">Lost & Found Hub</span>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" href="index.php">
                            <i class="fas fa-home me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'lost_items.php' ? 'active' : ''; ?>" href="lost_items.php">
                            <i class="fas fa-exclamation-triangle me-2"></i>Lost Items
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'found_items.php' ? 'active' : ''; ?>" href="found_items.php">
                            <i class="fas fa-check-circle me-2"></i>Found Items
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-plus-circle me-2"></i>Report Item
                        </a>
                        <ul class="dropdown-menu glass-effect border-0 shadow-strong">
                            <li><a class="dropdown-item" href="report_lost.php">
                                <i class="fas fa-exclamation-triangle me-2 text-danger"></i>Report Lost Item
                            </a></li>
                            <li><a class="dropdown-item" href="report_found.php">
                                <i class="fas fa-check-circle me-2 text-success"></i>Report Found Item
                            </a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'user_directory.php' ? 'active' : ''; ?>" href="user_directory.php">
                            <i class="fas fa-users me-2"></i>Community
                        </a>
                    </li>
                </ul>
                
                <div class="navbar-nav">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <?php
                        // Get user profile image
                        $stmt = $pdo->prepare("SELECT profile_image FROM users WHERE id = ?");
                        $stmt->execute([$_SESSION['user_id']]);
                        $current_user = $stmt->fetch();
                        ?>
                        <div class="navbar-text me-3 d-flex align-items-center">
                            <?php if ($current_user['profile_image'] && file_exists($current_user['profile_image'])): ?>
                                <img src="<?php echo htmlspecialchars($current_user['profile_image']); ?>" 
                                     alt="Profile" class="navbar-profile-img rounded-circle me-2 shadow-soft">
                            <?php else: ?>
                                <div class="navbar-profile-img rounded-circle me-2 d-flex align-items-center justify-content-center glass-effect">
                                    <i class="fas fa-user"></i>
                                </div>
                            <?php endif; ?>
                            <a href="profile.php" class="text-white text-decoration-none fw-medium">
                                <?php echo htmlspecialchars($_SESSION['username']); ?>
                            </a>
                        </div>
                        <?php
                        // Get unread message count
                        $stmt_unread = $pdo->prepare("SELECT COUNT(*) as unread FROM messages WHERE receiver_id = ? AND is_read = 0");
                        $stmt_unread->execute([$_SESSION['user_id']]);
                        $unread_messages = $stmt_unread->fetch()['unread'];
                        ?>
                        <a class="nav-link position-relative <?php echo basename($_SERVER['PHP_SELF']) == 'messenger.php' ? 'active' : ''; ?>" href="messenger.php">
                            <i class="fas fa-comment-dots me-2"></i>Messages
                            <?php if ($unread_messages > 0): ?>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger pulse-animation">
                                    <?php echo $unread_messages; ?>
                                </span>
                            <?php endif; ?>
                        </a>
                        <?php if (is_admin()): ?>
                            <a class="nav-link" href="admin/dashboard.php">
                                <i class="fas fa-shield-alt me-2"></i>Admin Panel
                            </a>
                        <?php endif; ?>
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    <?php else: ?>
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'login.php' ? 'active' : ''; ?>" href="login.php">
                            <i class="fas fa-sign-in-alt me-2"></i>Login
                        </a>
                        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'register.php' ? 'active' : ''; ?>" href="register.php">
                            <i class="fas fa-user-plus me-2"></i>Register
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
    
    <main class="container mt-4">