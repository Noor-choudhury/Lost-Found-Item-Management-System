    </main>
    
    <!-- Footer -->
    <footer class="text-light mt-5 py-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="d-flex align-items-center mb-3 mb-md-0">
                        <div class="brand-icon me-3">
                            <i class="fas fa-search-location"></i>
                        </div>
                        <div>
                            <h5 class="mb-1">Lost & Found Hub</h5>
                            <p class="mb-0 text-light">Reuniting people with their belongings through community collaboration.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="text-md-end">
                        <div class="d-flex justify-content-md-end justify-content-center mb-2">
                            <a href="#" class="text-light me-3 text-decoration-none">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="text-light me-3 text-decoration-none">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="#" class="text-light me-3 text-decoration-none">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="#" class="text-light text-decoration-none">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                        </div>
                        <p class="mb-1">&copy; 2025 Lost & Found Hub. All rights reserved.</p>
                        <small class="text-light opacity-75">Built with ❤️ using PHP, MySQL & Bootstrap</small>
                    </div>
                </div>
            </div>
            <hr class="my-3 opacity-25">
            <div class="row">
                <div class="col-12 text-center">
                    <small class="text-light opacity-75">
                        <i class="fas fa-shield-alt me-1"></i>
                        Your privacy and security are our top priorities
                    </small>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="assets/js/script.js"></script>
    <script src="assets/js/modern-enhancements.js"></script>
</body>
</html>