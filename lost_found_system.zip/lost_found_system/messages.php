<?php
// Redirect to new messenger system
header('Location: messenger.php');
exit;
?>