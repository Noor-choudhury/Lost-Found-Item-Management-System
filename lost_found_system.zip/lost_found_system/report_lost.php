<?php
require_once 'includes/db_connect.php';

// Require login to report items
require_login();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize_input($_POST['title']);
    $description = sanitize_input($_POST['description']);
    $category = sanitize_input($_POST['category']);
    $date_reported = sanitize_input($_POST['date_reported']);
    $location = sanitize_input($_POST['location']);
    $contact_info = sanitize_input($_POST['contact_info']);
    
    // Validation
    if (empty($title) || empty($description) || empty($category) || empty($date_reported) || empty($location)) {
        $error = 'Please fill in all required fields.';
    } else {
        // Handle file upload
        $image_path = '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'assets/uploads/';
            
            // Create upload directory if it doesn't exist
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            
            // Check file size (5MB max)
            if ($_FILES['image']['size'] > 5 * 1024 * 1024) {
                $error = 'File size too large. Maximum 5MB allowed.';
            } elseif (in_array($file_extension, $allowed_extensions)) {
                $new_filename = uniqid() . '.' . $file_extension;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                    $image_path = $upload_path;
                } else {
                    $error = 'Failed to upload image. Please check directory permissions.';
                }
            } else {
                $error = 'Invalid file type. Please upload JPG, PNG or GIF images only.';
            }
        } elseif (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
            $error = 'File upload error occurred.';
        }
        
        if (!$error) {
            // Insert item into database
            $stmt = $pdo->prepare("
                INSERT INTO items (user_id, title, description, category, status, date_reported, location, contact_info, image_path) 
                VALUES (?, ?, ?, ?, 'Lost', ?, ?, ?, ?)
            ");
            
            if ($stmt->execute([$_SESSION['user_id'], $title, $description, $category, $date_reported, $location, $contact_info, $image_path])) {
                $success = 'Lost item reported successfully! Others can now see your report.';
                // Clear form data on success
                $_POST = array();
            } else {
                $error = 'Failed to report item. Please try again.';
            }
        }
    }
}

$page_title = 'Report Lost Item - Lost & Found System';
include 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="form-section">
            <div class="text-center mb-4">
                <h2><i class="fas fa-exclamation-triangle text-danger me-2"></i>Report Lost Item</h2>
                <p class="text-muted">Help others help you find your lost item</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success" role="alert">
                    <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                    <div class="mt-2">
                        <a href="lost_items.php" class="btn btn-sm btn-outline-success me-2">View All Lost Items</a>
                        <a href="index.php" class="btn btn-sm btn-outline-primary">Go Home</a>
                    </div>
                </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="title" class="form-label">Item Title <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="title" name="title" 
                           placeholder="e.g., Black iPhone 12 with blue case"
                           value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>"
                           required>
                    <div class="invalid-feedback">Please provide an item title.</div>
                </div>
                
                <div class="mb-3">
                    <label for="description" class="form-label">Description <span class="text-danger">*</span></label>
                    <textarea class="form-control" id="description" name="description" rows="4" 
                              placeholder="Describe your lost item in detail - color, brand, distinctive features, etc."
                              required><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                    <div class="invalid-feedback">Please provide a description.</div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="category" class="form-label">Category <span class="text-danger">*</span></label>
                        <select class="form-select" id="category" name="category" required>
                            <option value="">Select Category</option>
                            <option value="Phone" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Phone') ? 'selected' : ''; ?>>Phone</option>
                            <option value="Wallet" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Wallet') ? 'selected' : ''; ?>>Wallet</option>
                            <option value="ID" <?php echo (isset($_POST['category']) && $_POST['category'] === 'ID') ? 'selected' : ''; ?>>ID</option>
                            <option value="Keys" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Keys') ? 'selected' : ''; ?>>Keys</option>
                            <option value="Jewelry" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Jewelry') ? 'selected' : ''; ?>>Jewelry</option>
                            <option value="Electronics" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Electronics') ? 'selected' : ''; ?>>Electronics</option>
                            <option value="Clothing" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Clothing') ? 'selected' : ''; ?>>Clothing</option>
                            <option value="Books" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Books') ? 'selected' : ''; ?>>Books</option>
                            <option value="Other" <?php echo (isset($_POST['category']) && $_POST['category'] === 'Other') ? 'selected' : ''; ?>>Other</option>
                        </select>
                        <div class="invalid-feedback">Please select a category.</div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="date_reported" class="form-label">Date Lost <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="date_reported" name="date_reported" 
                               max="<?php echo date('Y-m-d'); ?>"
                               value="<?php echo isset($_POST['date_reported']) ? $_POST['date_reported'] : date('Y-m-d'); ?>"
                               required>
                        <div class="invalid-feedback">Please provide the date when you lost the item.</div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="location" class="form-label">Last Known Location <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="location" name="location" 
                           placeholder="e.g., Central Park near the fountain, Main Street Coffee Shop"
                           value="<?php echo isset($_POST['location']) ? htmlspecialchars($_POST['location']) : ''; ?>"
                           required>
                    <div class="invalid-feedback">Please provide the last known location.</div>
                </div>
                
                <div class="mb-3">
                    <label for="contact_info" class="form-label">Contact Information</label>
                    <input type="text" class="form-control" id="contact_info" name="contact_info" 
                           placeholder="Phone number, email, or preferred contact method"
                           value="<?php echo isset($_POST['contact_info']) ? htmlspecialchars($_POST['contact_info']) : ''; ?>">
                    <div class="form-text">This will be shown to people who might have found your item.</div>
                </div>
                
                <div class="mb-4">
                    <label for="image" class="form-label">Upload Photo</label>
                    <div class="file-upload-area" onclick="document.getElementById('image').click();">
                        <input type="file" class="d-none" id="image" name="image" accept="image/*">
                        <div class="file-upload-text">
                            <i class="fas fa-cloud-upload-alt fa-2x text-muted mb-2"></i>
                            <p class="mb-0">Click to select or drag and drop an image</p>
                            <small class="text-muted">Supported formats: JPG, PNG, GIF (Max 5MB)</small>
                        </div>
                        <div class="file-preview"></div>
                    </div>
                </div>
                
                <div class="d-grid">
                    <button type="submit" class="btn btn-danger btn-lg">
                        <i class="fas fa-exclamation-triangle me-2"></i>Report Lost Item
                    </button>
                </div>
            </form>
            
            <div class="text-center mt-4">
                <p class="text-muted">
                    <i class="fas fa-info-circle me-1"></i>
                    Your report will be visible to all users to help you find your item.
                </p>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>