<?php
require_once 'includes/db_connect.php';
require_login();

$current_user_id = $_SESSION['user_id'];

// Get all users the current user has chatted with
$stmt = $pdo->prepare("
    SELECT DISTINCT
        u.id,
        u.username,
        u.full_name,
        u.profile_image,
        m.last_message,
        m.last_timestamp,
        m.unread_count
    FROM users u
    INNER JOIN (
        SELECT 
            CASE 
                WHEN sender_id = ? THEN receiver_id 
                ELSE sender_id 
            END as other_user_id,
            MAX(timestamp) as last_timestamp,
            SUBSTRING(
                (SELECT message FROM messages m2 
                 WHERE (m2.sender_id = ? AND m2.receiver_id = other_user_id) 
                    OR (m2.sender_id = other_user_id AND m2.receiver_id = ?)
                 ORDER BY m2.timestamp DESC LIMIT 1), 1, 50
            ) as last_message,
            COUNT(CASE WHEN receiver_id = ? AND is_read = 0 THEN 1 END) as unread_count
        FROM messages 
        WHERE sender_id = ? OR receiver_id = ?
        GROUP BY other_user_id
    ) m ON u.id = m.other_user_id
    ORDER BY m.last_timestamp DESC
");

$stmt->execute([
    $current_user_id, $current_user_id, $current_user_id, 
    $current_user_id, $current_user_id, $current_user_id
]);
$chats = $stmt->fetchAll();

if (empty($chats)): ?>
    <div class="text-center p-4 text-muted">
        <i class="fas fa-comments fa-2x mb-2"></i>
        <p>No conversations yet</p>
        <small>Start a new chat to begin messaging</small>
    </div>
<?php else: ?>
    <?php foreach ($chats as $chat): ?>
        <div class="user-item" onclick="window.location.href='messenger.php?user_id=<?php echo $chat['id']; ?>'">
            <div class="d-flex align-items-center">
                <?php if ($chat['profile_image'] && file_exists($chat['profile_image'])): ?>
                    <img src="<?php echo htmlspecialchars($chat['profile_image']); ?>" 
                         alt="Profile" class="user-avatar me-3">
                <?php else: ?>
                    <div class="user-avatar me-3 bg-secondary d-flex align-items-center justify-content-center">
                        <i class="fas fa-user text-white"></i>
                    </div>
                <?php endif; ?>
                
                <div class="flex-grow-1">
                    <div class="d-flex justify-content-between align-items-center">
                        <h6 class="mb-0"><?php echo htmlspecialchars($chat['full_name']); ?></h6>
                        <small class="text-muted">
                            <?php echo date('g:i A', strtotime($chat['last_timestamp'])); ?>
                        </small>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-muted">
                            <?php echo htmlspecialchars($chat['last_message']); ?>...
                        </small>
                        <?php if ($chat['unread_count'] > 0): ?>
                            <span class="unread-badge"><?php echo $chat['unread_count']; ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>