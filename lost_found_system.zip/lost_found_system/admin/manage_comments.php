<?php
require_once '../includes/db_connect.php';
require_admin();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $comment_id = (int)$_POST['comment_id'];
        
        switch ($_POST['action']) {
            case 'delete':
                $stmt = $pdo->prepare("DELETE FROM comments WHERE id = ?");
                $stmt->execute([$comment_id]);
                $success = "Comment deleted successfully.";
                break;
                
            case 'approve':
                $stmt = $pdo->prepare("UPDATE comments SET admin_approved = 1 WHERE id = ?");
                $stmt->execute([$comment_id]);
                $success = "Comment approved successfully.";
                break;
                
            case 'disapprove':
                $stmt = $pdo->prepare("UPDATE comments SET admin_approved = 0 WHERE id = ?");
                $stmt->execute([$comment_id]);
                $success = "Comment disapproved successfully.";
                break;
        }
    }
}

// Get comments with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 15;
$offset = ($page - 1) * $per_page;

$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$approval_filter = isset($_GET['approval']) ? $_GET['approval'] : '';

$where_conditions = [];
$params = [];

if ($search) {
    $where_conditions[] = "(c.message LIKE ? OR c.username LIKE ? OR i.title LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($approval_filter !== '') {
    $where_conditions[] = "c.admin_approved = ?";
    $params[] = (int)$approval_filter;
}

$where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get total count
$count_sql = "SELECT COUNT(*) as total FROM comments c 
              JOIN items i ON c.item_id = i.id 
              $where_clause";
$stmt = $pdo->prepare($count_sql);
$stmt->execute($params);
$total_comments = $stmt->fetch()['total'];
$total_pages = ceil($total_comments / $per_page);

// Get comments
$sql = "SELECT c.*, i.title as item_title, i.id as item_id FROM comments c 
        JOIN items i ON c.item_id = i.id 
        $where_clause 
        ORDER BY c.created_at DESC 
        LIMIT $per_page OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$comments = $stmt->fetchAll();

$page_title = 'Manage Comments - Admin Panel';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Admin Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-danger">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-shield-alt me-2"></i>Admin Panel
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="adminNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_items.php">
                            <i class="fas fa-boxes me-1"></i>Manage Items
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_users.php">
                            <i class="fas fa-users me-1"></i>Manage Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage_comments.php">
                            <i class="fas fa-comments me-1"></i>Manage Comments
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="settings.php">
                            <i class="fas fa-cog me-1"></i>Settings
                        </a>
                    </li>
                </ul>
                
                <div class="navbar-nav">
                    <span class="navbar-text me-3">
                        Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>
                    </span>
                    <a class="nav-link" href="../index.php" target="_blank">
                        <i class="fas fa-external-link-alt me-1"></i>View Site
                    </a>
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt me-1"></i>Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-12">
                <h1><i class="fas fa-comments me-2"></i>Manage Comments</h1>
                <p class="text-muted">Moderate user comments on lost and found items</p>
            </div>
        </div>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <!-- Search and Filter -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-6">
                        <label for="search" class="form-label">Search</label>
                        <input type="text" class="form-control" id="search" name="search" 
                               value="<?php echo htmlspecialchars($search); ?>" 
                               placeholder="Search by comment text, username, or item title">
                    </div>
                    <div class="col-md-3">
                        <label for="approval" class="form-label">Approval Status</label>
                        <select class="form-select" id="approval" name="approval">
                            <option value="">All Comments</option>
                            <option value="1" <?php echo $approval_filter === '1' ? 'selected' : ''; ?>>Approved</option>
                            <option value="0" <?php echo $approval_filter === '0' ? 'selected' : ''; ?>>Not Approved</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">&nbsp;</label>
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search me-1"></i>Search
                            </button>
                            <a href="manage_comments.php" class="btn btn-secondary">
                                <i class="fas fa-times me-1"></i>Clear
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Comments Table -->
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-list me-2"></i>Comments (<?php echo $total_comments; ?> total)</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Comment</th>
                                <th>Item</th>
                                <th>User</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($comments as $comment): ?>
                            <tr>
                                <td><?php echo $comment['id']; ?></td>
                                <td>
                                    <div class="comment-text" style="max-width: 300px;">
                                        <?php echo htmlspecialchars($comment['message']); ?>
                                    </div>
                                </td>
                                <td>
                                    <a href="../item_details.php?id=<?php echo $comment['item_id']; ?>" 
                                       target="_blank" class="text-decoration-none">
                                        <?php echo htmlspecialchars($comment['item_title']); ?>
                                        <i class="fas fa-external-link-alt ms-1 small"></i>
                                    </a>
                                </td>
                                <td><?php echo htmlspecialchars($comment['username']); ?></td>
                                <td><?php echo date('M j, Y H:i', strtotime($comment['created_at'])); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $comment['admin_approved'] ? 'success' : 'warning'; ?>">
                                        <?php echo $comment['admin_approved'] ? 'Approved' : 'Pending'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <?php if ($comment['admin_approved']): ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="comment_id" value="<?php echo $comment['id']; ?>">
                                                <button type="submit" name="action" value="disapprove" 
                                                        class="btn btn-sm btn-outline-warning"
                                                        onclick="return confirm('Disapprove this comment?')">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="comment_id" value="<?php echo $comment['id']; ?>">
                                                <button type="submit" name="action" value="approve" 
                                                        class="btn btn-sm btn-outline-success"
                                                        onclick="return confirm('Approve this comment?')">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="comment_id" value="<?php echo $comment['id']; ?>">
                                            <button type="submit" name="action" value="delete" 
                                                    class="btn btn-sm btn-outline-danger"
                                                    onclick="return confirm('Are you sure you want to delete this comment?')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <nav aria-label="Comments pagination">
                    <ul class="pagination justify-content-center">
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&approval=<?php echo urlencode($approval_filter); ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>