<?php
require_once '../includes/db_connect.php';
require_admin();

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings = [
        'site_name' => sanitize_input($_POST['site_name']),
        'admin_email' => sanitize_input($_POST['admin_email']),
        'items_per_page' => (int)$_POST['items_per_page'],
        'require_approval' => isset($_POST['require_approval']) ? '1' : '0'
    ];
    
    foreach ($settings as $key => $value) {
        $stmt = $pdo->prepare("INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) 
                              ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        $stmt->execute([$key, $value]);
    }
    
    $success = "Settings updated successfully.";
}

// Get current settings
$stmt = $pdo->query("SELECT setting_key, setting_value FROM site_settings");
$settings_data = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Default values
$current_settings = [
    'site_name' => $settings_data['site_name'] ?? 'Lost & Found System',
    'admin_email' => $settings_data['admin_email'] ?? 'admin@example.com',
    'items_per_page' => $settings_data['items_per_page'] ?? 10,
    'require_approval' => $settings_data['require_approval'] ?? '0'
];

$page_title = 'Settings - Admin Panel';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Admin Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-danger">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-shield-alt me-2"></i>Admin Panel
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="adminNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_items.php">
                            <i class="fas fa-boxes me-1"></i>Manage Items
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_users.php">
                            <i class="fas fa-users me-1"></i>Manage Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage_comments.php">
                            <i class="fas fa-comments me-1"></i>Manage Comments
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="settings.php">
                            <i class="fas fa-cog me-1"></i>Settings
                        </a>
                    </li>
                </ul>
                
                <div class="navbar-nav">
                    <span class="navbar-text me-3">
                        Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>
                    </span>
                    <a class="nav-link" href="../index.php" target="_blank">
                        <i class="fas fa-external-link-alt me-1"></i>View Site
                    </a>
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt me-1"></i>Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-12">
                <h1><i class="fas fa-cog me-2"></i>System Settings</h1>
                <p class="text-muted">Configure your Lost & Found system</p>
            </div>
        </div>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-sliders-h me-2"></i>General Settings</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label for="site_name" class="form-label">Site Name</label>
                                <input type="text" class="form-control" id="site_name" name="site_name" 
                                       value="<?php echo htmlspecialchars($current_settings['site_name']); ?>" required>
                                <div class="form-text">The name that appears in the site header and title.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="admin_email" class="form-label">Admin Email</label>
                                <input type="email" class="form-control" id="admin_email" name="admin_email" 
                                       value="<?php echo htmlspecialchars($current_settings['admin_email']); ?>" required>
                                <div class="form-text">Email address for system notifications and contact.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="items_per_page" class="form-label">Items per Page</label>
                                <select class="form-select" id="items_per_page" name="items_per_page">
                                    <option value="5" <?php echo $current_settings['items_per_page'] == 5 ? 'selected' : ''; ?>>5</option>
                                    <option value="10" <?php echo $current_settings['items_per_page'] == 10 ? 'selected' : ''; ?>>10</option>
                                    <option value="15" <?php echo $current_settings['items_per_page'] == 15 ? 'selected' : ''; ?>>15</option>
                                    <option value="20" <?php echo $current_settings['items_per_page'] == 20 ? 'selected' : ''; ?>>20</option>
                                    <option value="25" <?php echo $current_settings['items_per_page'] == 25 ? 'selected' : ''; ?>>25</option>
                                </select>
                                <div class="form-text">Number of items to display per page in listings.</div>
                            </div>
                            
                            <div class="mb-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="require_approval" name="require_approval" 
                                           <?php echo $current_settings['require_approval'] == '1' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="require_approval">
                                        Require Admin Approval for New Items
                                    </label>
                                    <div class="form-text">When enabled, new lost/found items must be approved by an admin before appearing on the site.</div>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Save Settings
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-info-circle me-2"></i>System Information</h5>
                    </div>
                    <div class="card-body">
                        <dl class="row">
                            <dt class="col-sm-6">PHP Version:</dt>
                            <dd class="col-sm-6"><?php echo PHP_VERSION; ?></dd>
                            
                            <dt class="col-sm-6">Database:</dt>
                            <dd class="col-sm-6">MySQL</dd>
                            
                            <dt class="col-sm-6">Server Time:</dt>
                            <dd class="col-sm-6"><?php echo date('Y-m-d H:i:s'); ?></dd>
                            
                            <dt class="col-sm-6">System Version:</dt>
                            <dd class="col-sm-6">1.0.0</dd>
                        </dl>
                    </div>
                </div>
                
                <div class="card mt-4">
                    <div class="card-header">
                        <h5><i class="fas fa-tools me-2"></i>Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="dashboard.php" class="btn btn-outline-primary">
                                <i class="fas fa-tachometer-alt me-2"></i>View Dashboard
                            </a>
                            <a href="../index.php" class="btn btn-outline-info" target="_blank">
                                <i class="fas fa-external-link-alt me-2"></i>View Website
                            </a>
                            <button class="btn btn-outline-warning" onclick="if(confirm('Clear all resolved items?')) { /* Add clear function */ }">
                                <i class="fas fa-broom me-2"></i>Clear Resolved Items
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>