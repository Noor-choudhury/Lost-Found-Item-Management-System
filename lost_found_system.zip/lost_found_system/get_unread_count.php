<?php
require_once 'includes/db_connect.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    echo json_encode(['count' => 0]);
    exit;
}

$current_user_id = $_SESSION['user_id'];

// Get total unread message count
$stmt = $pdo->prepare("
    SELECT COUNT(*) as unread_count 
    FROM messages 
    WHERE receiver_id = ? AND is_read = 0
");
$stmt->execute([$current_user_id]);
$result = $stmt->fetch();

echo json_encode(['count' => (int)$result['unread_count']]);
?>