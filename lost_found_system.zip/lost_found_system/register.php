<?php
require_once 'includes/db_connect.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize_input($_POST['username']);
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $full_name = sanitize_input($_POST['full_name']);
    $phone = sanitize_input($_POST['phone']);
    
    // Handle profile image upload
    $profile_image = '';
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'assets/uploads/profiles/';
        
        // Create upload directory if it doesn't exist
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        
        // Check file size (2MB max for profile images)
        if ($_FILES['profile_image']['size'] > 2 * 1024 * 1024) {
            $error = 'Profile image size too large. Maximum 2MB allowed.';
        } elseif (in_array($file_extension, $allowed_extensions)) {
            $new_filename = 'profile_' . uniqid() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
                $profile_image = $upload_path;
            } else {
                $error = 'Failed to upload profile image. Please check directory permissions.';
            }
        } else {
            $error = 'Invalid file type for profile image. Please upload JPG, PNG or GIF images only.';
        }
    }
    
    // Validation
    if (empty($username) || empty($email) || empty($password) || empty($full_name)) {
        $error = 'Please fill in all required fields.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } else {
        // Check if username or email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        
        if ($stmt->fetch()) {
            $error = 'Username or email already exists.';
        } else {
            // Hash password and insert user
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, full_name, phone, profile_image) VALUES (?, ?, ?, ?, ?, ?)");
            
            if ($stmt->execute([$username, $email, $hashed_password, $full_name, $phone, $profile_image])) {
                $success = 'Registration successful! You can now log in.';
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
    }
}

$page_title = 'Register - Lost & Found System';
include 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        <div class="form-section">
            <div class="text-center mb-4">
                <h2><i class="fas fa-user-plus text-primary me-2"></i>Create Account</h2>
                <p class="text-muted">Join our community to report and find lost items</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success" role="alert">
                    <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="needs-validation" enctype="multipart/form-data" novalidate>
                <div class="mb-3">
                    <label for="username" class="form-label">Username <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="username" name="username" 
                           value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                           required>
                    <div class="invalid-feedback">Please choose a username.</div>
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" id="email" name="email"
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                           required>
                    <div class="invalid-feedback">Please provide a valid email.</div>
                </div>
                
                <div class="mb-3">
                    <label for="full_name" class="form-label">Full Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="full_name" name="full_name"
                           value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>"
                           required>
                    <div class="invalid-feedback">Please provide your full name.</div>
                </div>
                
                <div class="mb-3">
                    <label for="phone" class="form-label">Phone Number</label>
                    <input type="tel" class="form-control" id="phone" name="phone"
                           value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                </div>
                
                <div class="mb-3">
                    <label for="profile_image" class="form-label">Profile Image</label>
                    <div class="profile-upload-area" onclick="document.getElementById('profile_image').click();" style="border: 2px dashed #ddd; padding: 20px; border-radius: 8px; cursor: pointer; background: #f8f9fa;">
                        <input type="file" class="d-none" id="profile_image" name="profile_image" accept="image/*" onchange="previewImage(this)">
                        <div class="profile-upload-text text-center" id="upload-text">
                            <i class="fas fa-user-circle fa-3x text-muted mb-2"></i>
                            <p class="mb-0">Click to upload profile image</p>
                            <small class="text-muted">JPG, PNG, GIF (Max 2MB)</small>
                        </div>
                        <div class="profile-preview text-center" id="image-preview" style="display: none;">
                            <img id="preview-img" src="" alt="Profile Preview" style="max-width: 150px; max-height: 150px; border-radius: 50%; object-fit: cover; border: 3px solid #007bff;">
                            <p class="mt-2 mb-0"><small class="text-success">Image selected successfully!</small></p>
                        </div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="password" class="form-label">Password <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="password" name="password" required minlength="6">
                        <button class="btn btn-outline-secondary" type="button" id="togglePassword" onclick="togglePasswordVisibility('password', 'togglePassword')">
                            <i class="fas fa-eye" id="passwordIcon"></i>
                        </button>
                    </div>
                    <div class="form-text">Password must be at least 6 characters long.</div>
                    <div class="invalid-feedback">Please provide a password (min 6 characters).</div>
                </div>
                
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        <button class="btn btn-outline-secondary" type="button" id="toggleConfirmPassword" onclick="togglePasswordVisibility('confirm_password', 'toggleConfirmPassword')">
                            <i class="fas fa-eye" id="confirmPasswordIcon"></i>
                        </button>
                    </div>
                    <div class="invalid-feedback">Please confirm your password.</div>
                </div>
                
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-user-plus me-2"></i>Create Account
                    </button>
                </div>
            </form>
            
            <div class="text-center mt-4">
                <p class="mb-0">Already have an account? 
                    <a href="login.php" class="text-decoration-none">Sign in here</a>
                </p>
            </div>
        </div>
    </div>
</div>

<script>
function previewImage(input) {
    const file = input.files[0];
    const uploadText = document.getElementById('upload-text');
    const imagePreview = document.getElementById('image-preview');
    const previewImg = document.getElementById('preview-img');
    
    if (file) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            uploadText.style.display = 'none';
            imagePreview.style.display = 'block';
        };
        
        reader.readAsDataURL(file);
    } else {
        uploadText.style.display = 'block';
        imagePreview.style.display = 'none';
    }
}

function togglePasswordVisibility(passwordId, buttonId) {
    const passwordInput = document.getElementById(passwordId);
    const toggleButton = document.getElementById(buttonId);
    const icon = toggleButton.querySelector('i');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Add hover effects
document.addEventListener('DOMContentLoaded', function() {
    const uploadArea = document.querySelector('.profile-upload-area');
    
    uploadArea.addEventListener('mouseenter', function() {
        this.style.borderColor = '#007bff';
        this.style.backgroundColor = '#e3f2fd';
    });
    
    uploadArea.addEventListener('mouseleave', function() {
        this.style.borderColor = '#ddd';
        this.style.backgroundColor = '#f8f9fa';
    });
});
</script>

<?php include 'includes/footer.php'; ?>