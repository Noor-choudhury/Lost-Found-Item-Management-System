<?php
require_once 'includes/db_connect.php';

// Search parameters
$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$category = isset($_GET['category']) ? $_GET['category'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';
$location = isset($_GET['location']) ? $_GET['location'] : '';

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Sorting
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'date_desc';
$sort_options = [
    'date_desc' => 'i.created_at DESC',
    'date_asc' => 'i.created_at ASC',
    'title_asc' => 'i.title ASC',
    'title_desc' => 'i.title DESC',
    'location_asc' => 'i.location ASC'
];
$order_by = $sort_options[$sort] ?? $sort_options['date_desc'];

// Build WHERE clause
$where_conditions = [];
$params = [];

if ($query) {
    $where_conditions[] = "(i.title LIKE ? OR i.description LIKE ? OR i.location LIKE ?)";
    $params[] = "%$query%";
    $params[] = "%$query%";
    $params[] = "%$query%";
}

if ($category) {
    $where_conditions[] = "i.category = ?";
    $params[] = $category;
}

if ($status) {
    $where_conditions[] = "i.status = ?";
    $params[] = $status;
}

if ($location) {
    $where_conditions[] = "i.location LIKE ?";
    $params[] = "%$location%";
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get total count for pagination
$count_sql = "SELECT COUNT(*) as total FROM items i $where_clause";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_items = $count_stmt->fetch()['total'];
$total_pages = ceil($total_items / $per_page);

// Get items
$sql = "
    SELECT i.*, u.username, u.full_name 
    FROM items i 
    JOIN users u ON i.user_id = u.id 
    $where_clause 
    ORDER BY $order_by 
    LIMIT $per_page OFFSET $offset
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll();

$page_title = 'Search Results - Lost & Found System';
include 'includes/header.php';
?>

<div class="mb-4">
    <h1><i class="fas fa-search text-primary me-2"></i>Search Items</h1>
    <?php if ($query || $category || $status || $location): ?>
        <p class="text-muted mb-0">
            Search results for: 
            <?php if ($query): ?><strong>"<?php echo htmlspecialchars($query); ?>"</strong><?php endif; ?>
            <?php if ($category): ?> in <strong><?php echo htmlspecialchars($category); ?></strong><?php endif; ?>
            <?php if ($status): ?> - <strong><?php echo htmlspecialchars($status); ?> items</strong><?php endif; ?>
            <?php if ($location): ?> near <strong><?php echo htmlspecialchars($location); ?></strong><?php endif; ?>
        </p>
    <?php else: ?>
        <p class="text-muted mb-0">Browse all items or use the search filters below</p>
    <?php endif; ?>
</div>

<!-- Advanced Search -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Search & Filter</h5>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-6">
                <label for="q" class="form-label">Search Keywords</label>
                <input type="text" class="form-control" name="q" id="q" 
                       placeholder="Search by title, description, or location..." 
                       value="<?php echo htmlspecialchars($query); ?>">
            </div>
            
            <div class="col-md-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" name="status" id="status">
                    <option value="">All Items</option>
                    <option value="Lost" <?php echo $status === 'Lost' ? 'selected' : ''; ?>>Lost Items</option>
                    <option value="Found" <?php echo $status === 'Found' ? 'selected' : ''; ?>>Found Items</option>
                </select>
            </div>
            
            <div class="col-md-3">
                <label for="category" class="form-label">Category</label>
                <select class="form-select" name="category" id="category">
                    <option value="">All Categories</option>
                    <option value="Phone" <?php echo $category === 'Phone' ? 'selected' : ''; ?>>Phone</option>
                    <option value="Wallet" <?php echo $category === 'Wallet' ? 'selected' : ''; ?>>Wallet</option>
                    <option value="ID" <?php echo $category === 'ID' ? 'selected' : ''; ?>>ID</option>
                    <option value="Keys" <?php echo $category === 'Keys' ? 'selected' : ''; ?>>Keys</option>
                    <option value="Jewelry" <?php echo $category === 'Jewelry' ? 'selected' : ''; ?>>Jewelry</option>
                    <option value="Electronics" <?php echo $category === 'Electronics' ? 'selected' : ''; ?>>Electronics</option>
                    <option value="Clothing" <?php echo $category === 'Clothing' ? 'selected' : ''; ?>>Clothing</option>
                    <option value="Books" <?php echo $category === 'Books' ? 'selected' : ''; ?>>Books</option>
                    <option value="Other" <?php echo $category === 'Other' ? 'selected' : ''; ?>>Other</option>
                </select>
            </div>
            
            <div class="col-md-6">
                <label for="location" class="form-label">Location</label>
                <input type="text" class="form-control" name="location" id="location" 
                       placeholder="Enter location..." value="<?php echo htmlspecialchars($location); ?>">
            </div>
            
            <div class="col-md-3">
                <label for="sort" class="form-label">Sort by</label>
                <select class="form-select" name="sort" id="sort">
                    <option value="date_desc" <?php echo $sort === 'date_desc' ? 'selected' : ''; ?>>Newest First</option>
                    <option value="date_asc" <?php echo $sort === 'date_asc' ? 'selected' : ''; ?>>Oldest First</option>
                    <option value="title_asc" <?php echo $sort === 'title_asc' ? 'selected' : ''; ?>>Title A-Z</option>
                    <option value="title_desc" <?php echo $sort === 'title_desc' ? 'selected' : ''; ?>>Title Z-A</option>
                    <option value="location_asc" <?php echo $sort === 'location_asc' ? 'selected' : ''; ?>>Location A-Z</option>
                </select>
            </div>
            
            <div class="col-md-3 d-flex align-items-end">
                <div class="w-100">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Search
                    </button>
                </div>
            </div>
            
            <div class="col-12">
                <a href="search.php" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-1"></i>Clear All Filters
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Results Summary -->
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <span class="text-muted">
            <?php if ($total_items > 0): ?>
                Showing <?php echo min(($page - 1) * $per_page + 1, $total_items); ?> - 
                <?php echo min($page * $per_page, $total_items); ?> of <?php echo $total_items; ?> items
            <?php else: ?>
                No items found
            <?php endif; ?>
        </span>
    </div>
</div>

<!-- Items Grid -->
<?php if (empty($items)): ?>
    <div class="text-center py-5">
        <i class="fas fa-search fa-3x text-muted mb-3"></i>
        <h4>No items found</h4>
        <p class="text-muted">Try adjusting your search criteria or browse all items.</p>
        <div class="mt-3">
            <a href="lost_items.php" class="btn btn-danger me-2">
                <i class="fas fa-exclamation-triangle me-1"></i>Browse Lost Items
            </a>
            <a href="found_items.php" class="btn btn-success">
                <i class="fas fa-check-circle me-1"></i>Browse Found Items
            </a>
        </div>
    </div>
<?php else: ?>
    <div class="item-grid">
        <?php foreach ($items as $item): ?>
            <div class="card fade-in">
                <?php if ($item['image_path']): ?>
                    <img src="<?php echo htmlspecialchars($item['image_path']); ?>" class="card-img-top" alt="Item image">
                <?php else: ?>
                    <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
                        <i class="fas fa-image fa-3x text-muted"></i>
                    </div>
                <?php endif; ?>
                
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="card-title mb-0"><?php echo htmlspecialchars($item['title']); ?></h5>
                        <span class="status-badge status-<?php echo strtolower($item['status']); ?> <?php echo $item['is_resolved'] ? 'status-resolved' : ''; ?>">
                            <?php echo $item['is_resolved'] ? 'Resolved' : htmlspecialchars($item['status']); ?>
                        </span>
                    </div>
                    
                    <div class="category-icon category-<?php echo strtolower($item['category']); ?> mb-2">
                        <i class="fas fa-<?php echo getCategoryIcon($item['category']); ?>"></i>
                    </div>
                    
                    <p class="card-text text-muted mb-2">
                        <?php echo htmlspecialchars(substr($item['description'], 0, 100)) . (strlen($item['description']) > 100 ? '...' : ''); ?>
                    </p>
                    
                    <div class="small text-muted mb-3">
                        <div><i class="fas fa-map-marker-alt me-1"></i><?php echo htmlspecialchars($item['location']); ?></div>
                        <div><i class="fas fa-calendar me-1"></i><?php echo date('M j, Y', strtotime($item['date_reported'])); ?></div>
                        <div><i class="fas fa-user me-1"></i>by <?php echo htmlspecialchars($item['username']); ?></div>
                    </div>
                    
                    <a href="item_details.php?id=<?php echo $item['id']; ?>" class="btn btn-<?php echo $item['status'] === 'Lost' ? 'danger' : 'success'; ?> btn-sm w-100">
                        <i class="fas fa-eye me-1"></i>View Details
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Search results pagination" class="mt-4">
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page - 1; ?>&q=<?php echo urlencode($query); ?>&sort=<?php echo $sort; ?>&category=<?php echo $category; ?>&status=<?php echo $status; ?>&location=<?php echo urlencode($location); ?>">
                            <i class="fas fa-chevron-left"></i> Previous
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&q=<?php echo urlencode($query); ?>&sort=<?php echo $sort; ?>&category=<?php echo $category; ?>&status=<?php echo $status; ?>&location=<?php echo urlencode($location); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $page + 1; ?>&q=<?php echo urlencode($query); ?>&sort=<?php echo $sort; ?>&category=<?php echo $category; ?>&status=<?php echo $status; ?>&location=<?php echo urlencode($location); ?>">
                            Next <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
<?php endif; ?>

<?php
function getCategoryIcon($category) {
    $icons = [
        'Phone' => 'mobile-alt',
        'Wallet' => 'wallet',
        'ID' => 'id-card',
        'Keys' => 'key',
        'Jewelry' => 'gem',
        'Electronics' => 'laptop',
        'Clothing' => 'tshirt',
        'Books' => 'book',
        'Other' => 'question'
    ];
    return $icons[$category] ?? 'question';
}

include 'includes/footer.php';
?>