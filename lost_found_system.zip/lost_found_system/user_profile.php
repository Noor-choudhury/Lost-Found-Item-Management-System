<?php
require_once 'includes/db_connect.php';

// Get user ID from URL parameter
$user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;

if (!$user_id) {
    header('Location: user_directory.php');
    exit();
}

// Get user information
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND status = 'active'");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: user_directory.php');
    exit();
}

$is_own_profile = isset($_SESSION['user_id']) && $_SESSION['user_id'] == $user_id;

// Get user's items
$stmt = $pdo->prepare("SELECT * FROM items WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$user_items = $stmt->fetchAll();

// Get user stats
$stmt = $pdo->prepare("SELECT 
    COUNT(*) as total_items,
    SUM(CASE WHEN status = 'Lost' THEN 1 ELSE 0 END) as lost_items,
    SUM(CASE WHEN status = 'Found' THEN 1 ELSE 0 END) as found_items,
    SUM(CASE WHEN is_resolved = 1 THEN 1 ELSE 0 END) as resolved_items
    FROM items WHERE user_id = ?");
$stmt->execute([$user_id]);
$stats = $stmt->fetch();

$page_title = htmlspecialchars($user['full_name']) . "'s Profile - Lost & Found System";
include 'includes/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <!-- Profile Card -->
        <div class="col-lg-4 col-md-5 mb-4">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <div class="profile-image-container mb-3">
                        <?php if ($user['profile_image'] && file_exists($user['profile_image'])): ?>
                            <img src="<?php echo htmlspecialchars($user['profile_image']); ?>" 
                                 alt="Profile Picture" class="profile-image-large rounded-circle border border-3 border-primary">
                        <?php else: ?>
                            <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center" 
                                 style="width: 120px; height: 120px;">
                                <i class="fas fa-user fa-4x text-muted"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <h3 class="mb-1"><?php echo htmlspecialchars($user['full_name']); ?></h3>
                    <p class="text-primary mb-2">@<?php echo htmlspecialchars($user['username']); ?></p>
                    
                   
                    
                    <div class="row text-center mb-3">
                        <div class="col">
                            <small class="text-muted d-block">
                                <i class="fas fa-envelope me-1"></i>
                                <?php echo htmlspecialchars($user['email']); ?>
                            </small>
                        </div>
                    </div>
                    
                    <?php if ($user['phone']): ?>
                        <div class="row text-center mb-3">
                            <div class="col">
                                <small class="text-muted">
                                    <i class="fas fa-phone me-1"></i>
                                    <?php echo htmlspecialchars($user['phone']); ?>
                                </small>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="row text-center mb-3">
                        <div class="col">
                            <small class="text-muted">
                                <i class="fas fa-calendar me-1"></i>
                                Joined <?php echo date('M Y', strtotime($user['created_at'])); ?>
                            </small>
                        </div>
                    </div>
                    
                    <?php if (!$is_own_profile && is_logged_in()): ?>
                        <div class="d-grid gap-2">
                            <a href="send_message.php?to_user_id=<?php echo $user['id']; ?>" class="btn btn-primary">
                                <i class="fas fa-envelope me-1"></i>Send Message
                            </a>
                        </div>
                    <?php elseif ($is_own_profile): ?>
                        <div class="d-grid gap-2">
                            <a href="edit_profile.php" class="btn btn-outline-primary">
                                <i class="fas fa-edit me-1"></i>Edit Profile
                            </a>
                            <a href="messages.php" class="btn btn-outline-success">
                                <i class="fas fa-inbox me-1"></i>Messages
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Stats Card -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-light">
                    <h6 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Activity Statistics</h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-6 mb-3">
                            <h4 class="text-primary mb-0"><?php echo $stats['total_items']; ?></h4>
                            <small class="text-muted">Total Reports</small>
                        </div>
                        <div class="col-6 mb-3">
                            <h4 class="text-success mb-0"><?php echo $stats['resolved_items']; ?></h4>
                            <small class="text-muted">Resolved</small>
                        </div>
                        <div class="col-6">
                            <h4 class="text-danger mb-0"><?php echo $stats['lost_items']; ?></h4>
                            <small class="text-muted">Lost Items</small>
                        </div>
                        <div class="col-6">
                            <h4 class="text-info mb-0"><?php echo $stats['found_items']; ?></h4>
                            <small class="text-muted">Found Items</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Items Section -->
        <div class="col-lg-8 col-md-7">
            <div class="card shadow-sm">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-list me-2"></i>
                        <?php echo $is_own_profile ? 'My' : htmlspecialchars($user['full_name']) . "'s"; ?> Items
                        <span class="badge bg-secondary ms-2"><?php echo count($user_items); ?></span>
                    </h5>
                    <?php if ($is_own_profile): ?>
                        <div class="btn-group btn-group-sm">
                            <a href="report_lost.php" class="btn btn-outline-danger">
                                <i class="fas fa-plus me-1"></i>Report Lost
                            </a>
                            <a href="report_found.php" class="btn btn-outline-success">
                                <i class="fas fa-plus me-1"></i>Report Found
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if (empty($user_items)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                            <h5 class="text-muted">No items reported yet</h5>
                            <?php if ($is_own_profile): ?>
                                <p class="text-muted">Start by reporting your first lost or found item!</p>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="row g-3">
                            <?php foreach ($user_items as $item): ?>
                                <div class="col-lg-6 col-md-12">
                                    <div class="card h-100 border-0 shadow-sm">
                                        <?php if ($item['image_path']): ?>
                                            <img src="<?php echo htmlspecialchars($item['image_path']); ?>" 
                                                 class="card-img-top lightbox-trigger" 
                                                 style="height: 180px; object-fit: cover; cursor: pointer;" 
                                                 alt="Item image"
                                                 data-lightbox="user-items"
                                                 data-title="<?php echo htmlspecialchars($item['title']); ?>">
                                        <?php else: ?>
                                            <div class="card-img-top bg-light d-flex align-items-center justify-content-center" 
                                                 style="height: 180px;">
                                                <i class="fas fa-image fa-3x text-muted"></i>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-start mb-2">
                                                <h6 class="card-title mb-0"><?php echo htmlspecialchars($item['title']); ?></h6>
                                                <span class="badge bg-<?php echo $item['status'] === 'Lost' ? 'danger' : 'success'; ?>">
                                                    <?php echo $item['status']; ?>
                                                </span>
                                            </div>
                                            
                                            <div class="category-icon category-<?php echo strtolower($item['category']); ?> mb-2">
                                                <i class="fas fa-<?php echo getCategoryIcon($item['category']); ?>"></i>
                                                <span class="ms-1"><?php echo htmlspecialchars($item['category']); ?></span>
                                            </div>
                                            
                                            <p class="card-text text-muted small">
                                                <?php echo htmlspecialchars(substr($item['description'], 0, 80)) . (strlen($item['description']) > 80 ? '...' : ''); ?>
                                            </p>
                                            
                                            <div class="d-flex justify-content-between align-items-center">
                                                <small class="text-muted">
                                                    <i class="fas fa-calendar me-1"></i>
                                                    <?php echo date('M j, Y', strtotime($item['created_at'])); ?>
                                                </small>
                                                <a href="item_details.php?id=<?php echo $item['id']; ?>" 
                                                   class="btn btn-sm btn-primary">
                                                    <i class="fas fa-eye me-1"></i>View
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Lightbox CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css">

<style>
.profile-image-large {
    width: 120px;
    height: 120px;
    object-fit: cover;
}

.category-icon {
    width: 1.5rem;
    height: 1.5rem;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    font-size: 0.75rem;
}

.category-phone { background-color: rgba(13, 110, 253, 0.1); color: var(--bs-primary); }
.category-wallet { background-color: rgba(25, 135, 84, 0.1); color: var(--bs-success); }
.category-id { background-color: rgba(220, 53, 69, 0.1); color: var(--bs-danger); }
.category-keys { background-color: rgba(255, 193, 7, 0.1); color: #856404; }
.category-jewelry { background-color: rgba(214, 51, 132, 0.1); color: #d63384; }
.category-electronics { background-color: rgba(13, 202, 240, 0.1); color: var(--bs-info); }
.category-clothing { background-color: rgba(108, 117, 125, 0.1); color: var(--bs-secondary); }
.category-books { background-color: rgba(102, 16, 242, 0.1); color: #6610f2; }
.category-other { background-color: rgba(108, 117, 125, 0.1); color: var(--bs-secondary); }
</style>

<!-- Lightbox JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>

<?php
function getCategoryIcon($category) {
    $icons = [
        'Phone' => 'mobile-alt',
        'Wallet' => 'wallet',
        'ID' => 'id-card',
        'Keys' => 'key',
        'Jewelry' => 'gem',
        'Electronics' => 'laptop',
        'Clothing' => 'tshirt',
        'Books' => 'book',
        'Other' => 'question'
    ];
    return $icons[$category] ?? 'question';
}

include 'includes/footer.php';
?>