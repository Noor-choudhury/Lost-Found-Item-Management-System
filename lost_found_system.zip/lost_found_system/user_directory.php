<?php
require_once 'includes/db_connect.php';

// Get search parameters
$search_term = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$search_type = isset($_GET['type']) ? sanitize_input($_GET['type']) : 'all';

// Pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Build search query
$where_conditions = ["status = 'active'"];
$params = [];

if ($search_term) {
    switch ($search_type) {
        case 'username':
            $where_conditions[] = "username LIKE ?";
            $params[] = "%$search_term%";
            break;
        case 'email':
            $where_conditions[] = "email LIKE ?";
            $params[] = "%$search_term%";
            break;
        case 'user_id':
            $where_conditions[] = "id = ?";
            $params[] = (int)$search_term;
            break;
        default: // all
            $where_conditions[] = "(username LIKE ? OR email LIKE ? OR full_name LIKE ?)";
            $params[] = "%$search_term%";
            $params[] = "%$search_term%";
            $params[] = "%$search_term%";
            break;
    }
}

$where_clause = "WHERE " . implode(" AND ", $where_conditions);

// Get total count
$count_sql = "SELECT COUNT(*) as total FROM users $where_clause";
$stmt = $pdo->prepare($count_sql);
$stmt->execute($params);
$total_users = $stmt->fetch()['total'];
$total_pages = ceil($total_users / $per_page);

// Get users
$sql = "SELECT id, username, email, full_name, profile_image, created_at FROM users $where_clause ORDER BY full_name ASC LIMIT $per_page OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$page_title = 'User Directory - Lost & Found System';
include 'includes/header.php';
?>

<div class="container mt-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2><i class="fas fa-users me-2"></i>User Directory</h2>
                    <p class="text-muted mb-0">Find and connect with other users in our community</p>
                </div>
                <div class="badge bg-primary fs-6">
                    <?php echo $total_users; ?> Users
                </div>
            </div>
        </div>
    </div>

    <!-- Search Form -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-6">
                    <label for="search" class="form-label">Search Users</label>
                    <input type="text" 
                           class="form-control" 
                           id="search" 
                           name="search" 
                           value="<?php echo htmlspecialchars($search_term); ?>"
                           placeholder="Enter username, email, name, or user ID">
                </div>
                <div class="col-md-4">
                    <label for="type" class="form-label">Search By</label>
                    <select class="form-select" id="type" name="type">
                        <option value="all" <?php echo $search_type === 'all' ? 'selected' : ''; ?>>All Fields</option>
                        <option value="username" <?php echo $search_type === 'username' ? 'selected' : ''; ?>>Username</option>
                        <option value="email" <?php echo $search_type === 'email' ? 'selected' : ''; ?>>Email</option>
                        <option value="user_id" <?php echo $search_type === 'user_id' ? 'selected' : ''; ?>>User ID</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">&nbsp;</label>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search me-1"></i>Search
                        </button>
                    </div>
                </div>
                <?php if ($search_term): ?>
                    <div class="col-12">
                        <a href="user_directory.php" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-times me-1"></i>Clear Search
                        </a>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- Users Grid -->
    <?php if (empty($users)): ?>
        <div class="text-center py-5">
            <i class="fas fa-users fa-4x text-muted mb-3"></i>
            <h4>No users found</h4>
            <p class="text-muted">
                <?php echo $search_term ? 'Try adjusting your search criteria.' : 'No users are currently registered.'; ?>
            </p>
        </div>
    <?php else: ?>
        <div class="row g-4 mb-4">
            <?php foreach ($users as $user): ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="card h-100 shadow-sm border-0 user-card">
                        <div class="card-body text-center p-4">
                            <!-- Profile Image -->
                            <div class="mb-3">
                                <?php if ($user['profile_image'] && file_exists($user['profile_image'])): ?>
                                    <img src="<?php echo htmlspecialchars($user['profile_image']); ?>" 
                                         alt="Profile" 
                                         class="rounded-circle border border-2 border-primary" 
                                         style="width: 80px; height: 80px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center border border-2 border-light" 
                                         style="width: 80px; height: 80px;">
                                        <i class="fas fa-user fa-2x text-muted"></i>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- User Info -->
                            <h6 class="card-title mb-1"><?php echo htmlspecialchars($user['full_name']); ?></h6>
                            <p class="text-primary small mb-1">@<?php echo htmlspecialchars($user['username']); ?></p>
                            <p class="text-muted small mb-0"><?php echo htmlspecialchars($user['email']); ?></p>
                            
                            <!-- Member Since -->
                            <div class="text-muted small mt-2 mb-3">
                                <i class="fas fa-calendar me-1"></i>
                                Member since <?php echo date('M Y', strtotime($user['created_at'])); ?>
                            </div>

                            <!-- Action Buttons -->
                            <div class="d-grid gap-2">
                                <a href="user_profile.php?user_id=<?php echo $user['id']; ?>" 
                                   class="btn btn-outline-primary btn-sm">
                                    <i class="fas fa-user me-1"></i>View Profile
                                </a>
                                <?php if (is_logged_in() && $_SESSION['user_id'] != $user['id']): ?>
                                    <a href="send_message.php?to_user_id=<?php echo $user['id']; ?>" 
                                       class="btn btn-primary btn-sm">
                                        <i class="fas fa-envelope me-1"></i>Send Message
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <nav aria-label="User directory pagination" class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search_term); ?>&type=<?php echo urlencode($search_type); ?>">
                                <i class="fas fa-chevron-left"></i> Previous
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php 
                    $start = max(1, $page - 2);
                    $end = min($total_pages, $page + 2);
                    ?>

                    <?php if ($start > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=1&search=<?php echo urlencode($search_term); ?>&type=<?php echo urlencode($search_type); ?>">1</a>
                        </li>
                        <?php if ($start > 2): ?>
                            <li class="page-item disabled"><span class="page-link">...</span></li>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php for ($i = $start; $i <= $end; $i++): ?>
                        <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search_term); ?>&type=<?php echo urlencode($search_type); ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($end < $total_pages): ?>
                        <?php if ($end < $total_pages - 1): ?>
                            <li class="page-item disabled"><span class="page-link">...</span></li>
                        <?php endif; ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $total_pages; ?>&search=<?php echo urlencode($search_term); ?>&type=<?php echo urlencode($search_type); ?>"><?php echo $total_pages; ?></a>
                        </li>
                    <?php endif; ?>

                    <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search_term); ?>&type=<?php echo urlencode($search_type); ?>">
                                Next <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>

<style>
.user-card {
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}

.user-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
}
</style>

<?php include 'includes/footer.php'; ?>